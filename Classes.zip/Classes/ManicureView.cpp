//
//  ManicureView.cpp
//  demo
//
//  Created by Pritesh on 05/01/26.
//

#include "Header.h"
Scene* ManicureView::createScene()
{
    return ManicureView::create();
}

bool ManicureView::init()
{
    if (!Scene::init())
        return false;
    
    isPopupFlag = false;
    t = 1;
    visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();

    outPosition = Vec2(2000*SCALE_RATIO_X,-2000*SCALE_RATIO_Y);
    
//MARK: Extra view
    
    particle_Shower = ParticleSystemQuad::create("shower 13.plist");
    particle_Shower->setPosition(Vec2::ZERO);
    particle_Shower->setLocalZOrder(100);
    particle_Shower->stopSystem();
    particle_Shower->setVisible(false);

    this->addChild(particle_Shower);
    
    btn_home = Sprite::create("home.png");
    btn_home->setPosition(Vec2(543*SCALE_RATIO_X,740*SCALE_RATIO_Y));
    btn_home->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(btn_home,5);
    
    M_bg = Sprite::create("M_bg.png");
    M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(M_bg);
    
    hand = Sprite::create(__String::createWithFormat("M1_%d.png",handNo)->getCString());
    hand->setPosition(Vec2(384*SCALE_RATIO_X,512*SCALE_RATIO_Y));
    hand->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
    this->addChild(hand);
    //hand->setVisible(false);
    
    
    Setup_View();
    Setup_Panel();
    setCoinPanel();
    
    black_M_bg = Sprite::create("blackbg.png");
    black_M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    black_M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(black_M_bg);
    black_M_bg->setVisible(false);

    ManicureView::openPopupView();

    moveDot = Sprite::create("CloseNormal.png");
    moveDot->setPosition(Vec2(SCALE_RATIO_X*12000,SCALE_RATIO_Y*152000));
    moveDot->setScale(SCALE_RATIO_X*0.4, SCALE_RATIO_Y*0.4);
    this->addChild(moveDot,-15);

    for (int i = 1; i <= 3; i++)
        soapDone[i] = false;
    currentSoapHint = -1;

    handHint = Sprite::create("indi_hand.png");
    handHint->setScale(SCALE_RATIO_X, SCALE_RATIO_Y);
    handHint->setVisible(false);
    this->addChild(handHint, 100);

  //  this->setScale(2.0);
    
    auto touchListener = EventListenerTouchOneByOne::create();
    
    touchListener->onTouchBegan = CC_CALLBACK_2(ManicureView::onTouchBegan, this);
    touchListener->onTouchEnded = CC_CALLBACK_2(ManicureView::onTouchEnded, this);
    touchListener->onTouchMoved = CC_CALLBACK_2(ManicureView::onTouchMoved, this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
    
    return true;
}
void ManicureView::Setup_View()
{
    handFullDust = Sprite::create("dust_4.png");
    handFullDust->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
    this->addChild(handFullDust);
    handFullDust->setPosition(Vec2(391*SCALE_RATIO_X,500*SCALE_RATIO_Y));
    
    
    for (int i = 1; i <= 3; i++) {
        handDust[i] = Sprite::create(__String::createWithFormat("dust_%d.png",i)->getCString());
        handDust[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(handDust[i]);
        
        handDotDust[i] = Sprite::create(__String::createWithFormat("dustdot_%d.png",i)->getCString());
        handDotDust[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(handDotDust[i]);
        
        
    }
    handDust[1]->setPosition(Vec2(341*SCALE_RATIO_X,406*SCALE_RATIO_Y));
    handDust[2]->setPosition(Vec2(429*SCALE_RATIO_X,389*SCALE_RATIO_Y));
    handDust[3]->setPosition(Vec2(374*SCALE_RATIO_X,476*SCALE_RATIO_Y));
    
    handDotDust[1]->setPosition(Vec2(356*SCALE_RATIO_X,476*SCALE_RATIO_Y));
    handDotDust[2]->setPosition(Vec2(419*SCALE_RATIO_X,376*SCALE_RATIO_Y));
    handDotDust[3]->setPosition(Vec2(345*SCALE_RATIO_X,375*SCALE_RATIO_Y));
    
    for (int i = 1; i <= 5; i++) {
        Dust_Nail[i] = Sprite::create(__String::createWithFormat("nail_dust_%d.png",i)->getCString());
        Dust_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(Dust_Nail[i]);
        
        Brok_Nail[i] = Sprite::create("brocken nails.png");
        Brok_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(Brok_Nail[i]);
    }
    
    Dust_Nail[1]->setPosition(Vec2(515*SCALE_RATIO_X,526*SCALE_RATIO_Y));
    Dust_Nail[2]->setPosition(Vec2(435*SCALE_RATIO_X,669*SCALE_RATIO_Y));
    Dust_Nail[3]->setPosition(Vec2(374*SCALE_RATIO_X,694*SCALE_RATIO_Y));
    Dust_Nail[4]->setPosition(Vec2(317*SCALE_RATIO_X,667*SCALE_RATIO_Y));
    Dust_Nail[5]->setPosition(Vec2(263*SCALE_RATIO_X,608*SCALE_RATIO_Y));
    
    Brok_Nail[1]->setPosition(Vec2(518*SCALE_RATIO_X,536*SCALE_RATIO_Y));
    Brok_Nail[2]->setPosition(Vec2(437*SCALE_RATIO_X,679*SCALE_RATIO_Y));
    Brok_Nail[3]->setPosition(Vec2(376*SCALE_RATIO_X,706*SCALE_RATIO_Y));
    Brok_Nail[4]->setPosition(Vec2(319*SCALE_RATIO_X,678*SCALE_RATIO_Y));
    Brok_Nail[5]->setPosition(Vec2(263*SCALE_RATIO_X,614*SCALE_RATIO_Y));
    
    //set Pimple
    {
        for (int i = 1; i <= 3; i++) {
            pimple[i] = Sprite::create("pimple1_1.png");
            this->addChild(pimple[i]);
            if (i == 1)
                pimple[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            else if (i == 2)
                pimple[i]->setScale(SCALE_RATIO_X*0.6,SCALE_RATIO_Y*0.6);
            else if (i == 3)
                pimple[i]->setScale(SCALE_RATIO_X*0.4,SCALE_RATIO_Y*0.4);
        }
        pimple[1]->setPosition(Vec2(420*SCALE_RATIO_X,462*SCALE_RATIO_Y));
        pimple[2]->setPosition(Vec2(334*SCALE_RATIO_X,428*SCALE_RATIO_Y));
        pimple[3]->setPosition(Vec2(299*SCALE_RATIO_X,503*SCALE_RATIO_Y));
        
        for (int i = 4; i <= 5; i++) {
            pimple[i] = Sprite::create("pimple5.png");
            this->addChild(pimple[i]);
            if (i == 4)
                pimple[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
            else if (i == 5)
                pimple[i]->setScale(SCALE_RATIO_X*0.6,SCALE_RATIO_Y*0.6);
        }
        pimple[4]->setPosition(Vec2(334*SCALE_RATIO_X,518*SCALE_RATIO_Y));
        pimple[5]->setPosition(Vec2(342*SCALE_RATIO_X,375*SCALE_RATIO_Y));
        
        for (int i = 6; i <= 7; i++) {
            pimple[i] = Sprite::create("pimple4.png");
            this->addChild(pimple[i]);
            if (i == 6)
                pimple[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
            else if (i == 7)
                pimple[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        }
        
        pimple[6]->setPosition(Vec2(417*SCALE_RATIO_X,541*SCALE_RATIO_Y));
        pimple[7]->setPosition(Vec2(439*SCALE_RATIO_X,424*SCALE_RATIO_Y));
        
        pimple[8] = Sprite::create("pimple2.png");
        this->addChild(pimple[8]);
        pimple[8]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
        pimple[8]->setFlippedX(true);
        pimple[8]->setPosition(Vec2(424*SCALE_RATIO_X,545*SCALE_RATIO_Y));
        
        for (int i = 1; i <= 3; i++) {
            pinksoap[i] = Sprite::create("pinksoap.png");
            pinksoap[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            this->addChild(pinksoap[i]);
            pinksoap[i]->setOpacity(0);
            
            pinksoapdummy[i] = Sprite::create("pinksoap.png");
            pinksoapdummy[i]->setScale(SCALE_RATIO_X*0.2,SCALE_RATIO_Y*0.2);
            this->addChild(pinksoapdummy[i]);
            pinksoapdummy[i]->setOpacity(0);

        }
        pinksoap[1]->setPosition(Vec2(325*SCALE_RATIO_X,387*SCALE_RATIO_Y));
        pinksoap[2]->setPosition(Vec2(363*SCALE_RATIO_X,481*SCALE_RATIO_Y));
        pinksoap[3]->setPosition(Vec2(416*SCALE_RATIO_X,393*SCALE_RATIO_Y));

        pinksoapdummy[1]->setPosition(Vec2(325*SCALE_RATIO_X,387*SCALE_RATIO_Y));
        pinksoapdummy[2]->setPosition(Vec2(363*SCALE_RATIO_X,481*SCALE_RATIO_Y));
        pinksoapdummy[3]->setPosition(Vec2(416*SCALE_RATIO_X,393*SCALE_RATIO_Y));

        soapHintPos[1] = Vec2(SCALE_RATIO_X*365,SCALE_RATIO_Y*366);
        soapHintPos[2] = Vec2(SCALE_RATIO_X*402,SCALE_RATIO_Y*449);
        soapHintPos[3] =Vec2(SCALE_RATIO_X*449,SCALE_RATIO_Y*371);

        
        for (int i = 1; i <= 3; i++) {
            whitecream[i] = Sprite::create("whitecream.png");
            whitecream[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            this->addChild(whitecream[i]);
                whitecream[i]->setOpacity(0);
        }
        whitecream[1]->setPosition(Vec2(323*SCALE_RATIO_X,448*SCALE_RATIO_Y));
        whitecream[2]->setPosition(Vec2(395*SCALE_RATIO_X,495*SCALE_RATIO_Y));
        whitecream[3]->setPosition(Vec2(422*SCALE_RATIO_X,408*SCALE_RATIO_Y));

        for (int i = 1; i <= 20; i++) {
            bubble[i] = Sprite::create("pinkbubble.png");
            bubble[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            this->addChild(bubble[i]);
            bubble[i]->setOpacity(0);
        }
        bubble[1]->setPosition(Vec2(309*SCALE_RATIO_X,537*SCALE_RATIO_Y));
        bubble[2]->setPosition(Vec2(303*SCALE_RATIO_X,589*SCALE_RATIO_Y));
        bubble[3]->setPosition(Vec2(350*SCALE_RATIO_X,624*SCALE_RATIO_Y));
        bubble[4]->setPosition(Vec2(355*SCALE_RATIO_X,579*SCALE_RATIO_Y));
        bubble[5]->setPosition(Vec2(419*SCALE_RATIO_X,621*SCALE_RATIO_Y));
        bubble[6]->setPosition(Vec2(418*SCALE_RATIO_X,575*SCALE_RATIO_Y));
        bubble[7]->setPosition(Vec2(371*SCALE_RATIO_X,532*SCALE_RATIO_Y));
        bubble[8]->setPosition(Vec2(321*SCALE_RATIO_X,490*SCALE_RATIO_Y));
        bubble[9]->setPosition(Vec2(391*SCALE_RATIO_X,489*SCALE_RATIO_Y));
        bubble[10]->setPosition(Vec2(433*SCALE_RATIO_X,529*SCALE_RATIO_Y));
        bubble[11]->setPosition(Vec2(442*SCALE_RATIO_X,476*SCALE_RATIO_Y));
        bubble[12]->setPosition(Vec2(481*SCALE_RATIO_X,470*SCALE_RATIO_Y));
        bubble[13]->setPosition(Vec2(329*SCALE_RATIO_X,450*SCALE_RATIO_Y));
        bubble[14]->setPosition(Vec2(393*SCALE_RATIO_X,451*SCALE_RATIO_Y));
        bubble[15]->setPosition(Vec2(339*SCALE_RATIO_X,405*SCALE_RATIO_Y));
        bubble[16]->setPosition(Vec2(405*SCALE_RATIO_X,409*SCALE_RATIO_Y));
        bubble[17]->setPosition(Vec2(466*SCALE_RATIO_X,434*SCALE_RATIO_Y));
        bubble[18]->setPosition(Vec2(457*SCALE_RATIO_X,395*SCALE_RATIO_Y));
        bubble[19]->setPosition(Vec2(350*SCALE_RATIO_X,378*SCALE_RATIO_Y));
        bubble[20]->setPosition(Vec2(430*SCALE_RATIO_X,387*SCALE_RATIO_Y));

    }
}
void ManicureView::Setup_Panel()
{
    panel = Sprite::create("PENAL.png");
    panel->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
    this->addChild(panel);
    panel->setPosition(Vec2(384*SCALE_RATIO_X,281*SCALE_RATIO_Y));
    
    toolpos[1] = Vec2(265*SCALE_RATIO_X,345*SCALE_RATIO_Y);
    toolpos[2] = Vec2(396*SCALE_RATIO_X,318*SCALE_RATIO_Y);
    toolpos[3] = Vec2(513*SCALE_RATIO_X,344*SCALE_RATIO_Y);
    toolpos[4] = Vec2(262*SCALE_RATIO_X,307*SCALE_RATIO_Y);
    toolpos[5] = Vec2(401*SCALE_RATIO_X,332*SCALE_RATIO_Y);
    toolpos[6] = Vec2(511*SCALE_RATIO_X,332*SCALE_RATIO_Y);
    toolpos[7] = Vec2(287*SCALE_RATIO_X,297*SCALE_RATIO_Y);
    toolpos[8] = Vec2(472*SCALE_RATIO_X,294*SCALE_RATIO_Y);
    
    for (int i = 1; i <= 8; i++) {
        PanelTool[i] = Sprite::create(__String::createWithFormat("PanelTool%d.png",i)->getCString());
        PanelTool[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(PanelTool[i]);
        PanelTool[i]->setOpacity(254);
        PanelTool[i]->setPosition(Vec2(toolpos[i].x,SCALE_RATIO_Y*-120));

    }
    
    float delay = 0.0f;

    for (int i = 1; i <= 3; i++)
    {
        PanelTool[i]->runAction(
            Sequence::create(
                DelayTime::create(delay),
                EaseCubicActionOut::create(
                    MoveTo::create(0.45f, toolpos[i])
                ),
                (i == 3) ? CallFunc::create([this](){
                    startSoapHint();
                }) : nullptr,
                nullptr
            )
        );

        delay += 0.6f;
    }
        
//    PanelTool[1]->runAction(Sequence::create(MoveTo::create(0.3, toolpos[1]), NULL));
//    PanelTool[2]->runAction(Sequence::create(MoveTo::create(0.6, toolpos[2]), NULL));
//    PanelTool[3]->runAction(Sequence::create(MoveTo::create(0.9, toolpos[3]),CallFunc::create([this]{
//        startSoapHint();
//    }), NULL));
    
//    PanelTool[1]->runAction(Sequence::create(DelayTime::create(0.0f),
//    EaseSineOut::create(MoveTo::create(0.3f, toolpos[1])),
//            nullptr
//        )
//    );
//    PanelTool[2]->runAction(
//        Sequence::create(
//            DelayTime::create(0.15f),
//            EaseSineOut::create(MoveTo::create(0.3f, toolpos[2])),
//            nullptr
//        )
//    );
//
//    PanelTool[3]->runAction(
//        Sequence::create(
//            DelayTime::create(0.3f),
//            EaseSineOut::create(MoveTo::create(0.3f, toolpos[3])),
//            CallFunc::create([this](){
//                startSoapHint();
//            }),
//            nullptr
//        )
//    );
    

    for (int i = 1; i <= 8; i++) {
        useTool[i] = Sprite::create(__String::createWithFormat("useTool%d.png",i)->getCString());
        useTool[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(useTool[i],1);
        useTool[i]->setPosition(Vec2(toolpos[i].x,SCALE_RATIO_Y*-120));

    }
    useTool[3]->setAnchorPoint(Point(0.5,0.1));
    useTool[6]->setAnchorPoint(Point(0.5,0.1));
    useTool[7]->setAnchorPoint(Point(0.5,0.1));
    useTool[8]->setAnchorPoint(Point(0.5,0.1));
    
    showerpipe = Sprite::create("useTool3_1.png");
    showerpipe->setScale(1.0);
    useTool[3]->addChild(showerpipe);
    showerpipe->setPosition(Vec2(61,-177));

    for (int i = 1; i <= 4; i++) {
        popupUseTool[i] = Sprite::create(__String::createWithFormat("PopTool%d.png",i)->getCString());
        popupUseTool[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(popupUseTool[i],1);
        popupUseTool[i]->setPosition(Vec2(SCALE_RATIO_X*1200,SCALE_RATIO_Y*288));
        popupUseTool[i]->setAnchorPoint(Point(0.5,0.2));
        popupUseTool[i]->setRotation(-20);
        popupUseTool[i]->setOpacity(254);
    }
    ManicureView::toolComplete(0.1);
}
bool ManicureView::onTouchBegan(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    if(btn_home->getBoundingBox().containsPoint(location) && btn_home->getOpacity() == 255){
        btn_home->setOpacity(254);
        UIButtonSFX
        Director::getInstance()->replaceScene(ManicureView::create());
    }
    if (isPopupFlag == true) {
        if(popupUseTool[1]->getBoundingBox().containsPoint(location) && popupUseTool[1]->getOpacity() == 255){
            popupUseTool[1]->setOpacity(254);
            ToolTapSound
            popupMoveFlag[1] = true;
        }
        
        if(popupUseTool[2]->getBoundingBox().containsPoint(location) && popupUseTool[2]->getOpacity() == 255){
            popupUseTool[2]->setOpacity(254);
            ToolTapSound
            popupMoveFlag[2] = true;
        }
        
        if(popupUseTool[3]->getBoundingBox().containsPoint(location) && popupUseTool[3]->getOpacity() == 255){
            popupUseTool[3]->setOpacity(254);
            ToolTapSound
            popupMoveFlag[3] = true;
        }
        
        if(popupUseTool[4]->getBoundingBox().containsPoint(location) && popupUseTool[4]->getOpacity() == 255){
            popupUseTool[4]->setOpacity(254);
            ToolTapSound
            popupMoveFlag[4] = true;
        }
    }
    else{
    if(PanelTool[1]->getBoundingBox().containsPoint(location) && PanelTool[1]->getOpacity() == 255 && ToolNo == 0){
        ToolTapSound
        PanelTool[1]->setOpacity(0);
        useTool[1]->setPosition(location);
        moveToolFlag[1] = true;
        handHint->setVisible(false);
        handHint->stopAllActions();
    }
    if(PanelTool[2]->getBoundingBox().containsPoint(location) && PanelTool[2]->getOpacity() == 255 && ToolNo == 1){
        ToolTapSound
        PanelTool[2]->setOpacity(0);
        useTool[2]->setPosition(location);
        moveToolFlag[2] = true;
    }
    if(PanelTool[3]->getBoundingBox().containsPoint(location) && PanelTool[3]->getOpacity() == 255){
        ToolTapSound
        PanelTool[3]->setOpacity(0);
        useTool[3]->setPosition(location);
        moveToolFlag[3] = true;
    }
    if(PanelTool[4]->getBoundingBox().containsPoint(location) && PanelTool[4]->getOpacity() == 255){
        ToolTapSound
        PanelTool[4]->setOpacity(0);
        useTool[4]->setPosition(location);
        moveToolFlag[4] = true;
    }
    if(PanelTool[5]->getBoundingBox().containsPoint(location) && PanelTool[5]->getOpacity() == 255){
        PanelTool[5]->setOpacity(254);
        ToolTapSound
        vw_pop->runAction(Sequence::create(DelayTime::create(0.5),CallFunc::create([this]{black_M_bg->setVisible(true);}),ScaleTo::create(0.5, SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0), NULL));
        vw_hand->runAction(Sequence::create(DelayTime::create(0.5),ScaleTo::create(0.5, SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0), NULL));
        isPopupFlag = true;
        popupUseTool[1]->runAction(Sequence::create(DelayTime::create(1.0),MoveTo::create(1.0, Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));
    }
    }
    if(PanelTool[6]->getBoundingBox().containsPoint(location) && PanelTool[6]->getOpacity() == 255){
        PanelTool[6]->setOpacity(254);
        ToolTapSound
        PanelTool[6]->setTexture("PanelTool6_1.png");
        useTool[6]->setPosition(location);
        moveToolFlag[6] = true;
        useTool[6]->setPosition(location);
    }
    
    if(PanelTool[7]->getBoundingBox().containsPoint(location) && PanelTool[7]->getOpacity() == 255){
        PanelTool[7]->setOpacity(0);
        ToolTapSound
        useTool[7]->setPosition(location);
        moveToolFlag[7] = true;
    }
    if(PanelTool[8]->getBoundingBox().containsPoint(location) && PanelTool[8]->getOpacity() == 255){
        PanelTool[8]->setOpacity(0);
        ToolTapSound
        useTool[8]->setPosition(location);
        moveToolFlag[8] = true;
    }
    return true;
}
void ManicureView::onTouchMoved(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    //pimplecleandummy[t]->setPosition(location);
    
    if (moveToolFlag[1] == true) {
        useTool[1]->setPosition(location);
        moveDot->setPosition(Point(location.x-20,location.y+55));
        
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(pinksoapdummy[i]->getBoundingBox()) && soapDone[i] == false) {
                soapDone[i] = true;
                soapcnt++;
                moveToolFlag[1] = false;
                useTool[1]->setPosition(location);
                pinksoapdummy[i]->setPosition(outPosition);
                pinksoap[i]->runAction(Sequence::create(DelayTime::create(0.15),FadeIn::create(0.0), NULL));
                Animation* tempAnim = Animation::create();
                tempAnim->addSpriteFrameWithFile("useTool1_1.png");
                tempAnim->addSpriteFrameWithFile("useTool1.png");
                tempAnim->addSpriteFrameWithFile("useTool1_1.png");
                tempAnim->setDelayPerUnit(0.1f);
                
                Animate* animate = Animate::create(tempAnim);
                
                // Run full sequence
                useTool[1]->runAction(
                                      Sequence::create(
                                                       animate,   // 1️⃣ play animation
                                                       MoveTo::create(0.5f, PanelTool[1]->getPosition()),
                                                       MoveTo::create(0.0f, outPosition),
                                                       CallFunc::create([this]() {
                                                           PanelTool[1]->setOpacity(255);
                                                           startSoapHint();
                                                       }),
                                                       nullptr
                                                       )
                                      );
            }
        }
        if (soapcnt >= 3) {
            soapcnt = 0;
            ToolNo = 1;
            scheduleOnce(schedule_selector(ManicureView::toolComplete),1.5);
        }
        
    }
    if (moveToolFlag[2] == true) {
        useTool[2]->setPosition(location);
        moveDot->setPosition(Point(location.x,location.y));
        for (int i = 1; i <= 20; i++) {
            if (moveDot->getBoundingBox().intersectsRect(bubble[i]->getBoundingBox()) && bubble[i]->getOpacity() == 0) {
                bubble[i]->setOpacity(255);
                handFullDust->setOpacity(handFullDust->getOpacity() - 4);
                bubblecnt++;
                if (bubblecnt == 11) {
                    isbubble11 = true;
                }
            }
        }
        if (isbubble11 == true) {
            isbubble11 = false;
            for (int i = 1; i <= 3; i++) {
                handDust[i]->runAction(Sequence::create(FadeOut::create(2.0), NULL));
                handDotDust[i]->runAction(Sequence::create(FadeOut::create(2.0), NULL));
                pinksoap[i]->runAction(Sequence::create(FadeOut::create(2.0), NULL));
            }
        }
        if (bubblecnt == 20) {
            bubblecnt = 0;
            for (int i = 1; i <= 3; i++) {
                pinksoap[i]->setOpacity(0);
                handDust[i]->setOpacity(0);
                handDotDust[i]->setOpacity(0);
            }
            handFullDust->setOpacity(0);
            moveToolFlag[2] = false;
            useTool[2]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[2]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[2]->setOpacity(255);
                ToolNo = 2;ManicureView::toolComplete(0.1);}),nullptr));
        }
    }
    if (moveToolFlag[3] == true) {
        //SimpleAudioEngine::getInstance()->playEffect("0805.mp3");
        ShowerSound
        useTool[3]->setPosition(location);
        moveDot->setPosition(Point(location.x-10,location.y+100));
        
        particle_Shower->setPosition(Point(location.x-10, location.y+100));
        
        if (!particle_Shower->isVisible()) {
            particle_Shower->setVisible(true);
            particle_Shower->resetSystem();   // emit start
        }
        for (int i = 1; i <= 20; i++) {
            if (moveDot->getBoundingBox().intersectsRect(bubble[i]->getBoundingBox()) && bubble[i]->getOpacity() == 255) {
                bubble[i]->setOpacity(0);
                bubblecnt++;
            }
        }
        if (bubblecnt == 20) {
            bubblecnt = 0;
            moveToolFlag[3] = false;
            
            particle_Shower->stopSystem();
            particle_Shower->setVisible(false);
            
            useTool[3]->runAction(
                                  Sequence::create(
                                                   MoveTo::create(0.5f, PanelTool[3]->getPosition()),
                                                   MoveTo::create(0.0f, outPosition),
                                                   CallFunc::create([this]() {
                                                       PanelTool[3]->setOpacity(255);
                                                       ToolNo = 3;
                                                       ManicureView::toolComplete(0.1);
                                                   }),
                                                   nullptr
                                                   )
                                  );
        }
    }
    if (moveToolFlag[4] == true){
        useTool[4]->setPosition(location);
        moveDot->setPosition(Vec2(location.x, location.y+(SCALE_RATIO_Y*50)));
        if (moveDot->getBoundingBox().intersectsRect(pimple[8]->getBoundingBox()))
        {
            GLubyte opacity = pimple[8]->getOpacity();
            if (opacity > 0)
            {
                opacity = (opacity > 10) ? opacity - 10 : 0;
                pimple[8]->setOpacity(opacity);
            }
            if (opacity == 0) {
                moveToolFlag[4] = false;
                useTool[4]->runAction(
                                      Sequence::create(
                                                       MoveTo::create(0.5f, PanelTool[4]->getPosition()),
                                                       MoveTo::create(0.0f, outPosition),
                                                       CallFunc::create([this]() {
                                                           PanelTool[4]->setOpacity(255);
                                                           ToolNo = 4;
                                                           ManicureView::toolComplete(0.1);
                                                       }),
                                                       nullptr
                                                       )
                                      );
            }
        }
        
    }
    if (moveToolFlag[6] == true) {
        useTool[6]->setPosition(location);
        moveDot->setPosition(Point(location.x-(SCALE_RATIO_X*10),location.y+(SCALE_RATIO_Y*105)));
        
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(whitecream[i]->getBoundingBox()) && whitecream[i]->getOpacity() == 0) {
                soapcnt++;
                whitecream[i]->setOpacity(255);
            }
        }
        if (soapcnt >= 3) {
            moveToolFlag[6] = false;
            soapcnt = 0;
            useTool[6]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[6]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[6]->setTexture("PanelTool6.png");
                }),nullptr));
            ToolNo = 6;
            scheduleOnce(schedule_selector(ManicureView::toolComplete),1.5);
        }
        
    }
    if (whitecreamFlag == true) {
        moveDot->setPosition(location);
        for (int i = 1; i <= 3; i++) {
                    if (moveDot->getBoundingBox().intersectsRect(
                            whitecream[i]->getBoundingBox())) {

                        GLubyte opacity = whitecream[i]->getOpacity();

                        if (opacity > 0) {
                            opacity = (opacity > 10) ? opacity - 10 : 0;
                            whitecream[i]->setOpacity(opacity);
                            if (opacity == 0 ) {
                        pimplecount++;
                    }
                }
            }
            if (pimplecount >= 3) {
                pimplecount = 0;
                ToolNo = 7;
                whitecreamFlag = false;
                scheduleOnce(schedule_selector(ManicureView::toolComplete), 1.2);
            }
        }
    }
    
    if (moveToolFlag[7] == true) {
        useTool[7]->setPosition(location);
        moveDot->setPosition(Point(location.x-(SCALE_RATIO_X*5),location.y+(SCALE_RATIO_Y*115)));

        static bool isTool7AnimRunning = false;

        Animation* tempAnim = Animation::create();
        tempAnim->addSpriteFrameWithFile("useTool7_1.png");
        tempAnim->addSpriteFrameWithFile("useTool7_2.png");
        tempAnim->addSpriteFrameWithFile("useTool7_3.png");
        tempAnim->setDelayPerUnit(0.1f);
        tempAnim->setLoops(-1);   // continuous animation

        Animate* animate = Animate::create(tempAnim);

        
        for (int i = 1; i <= 5; i++) {
                    if (moveDot->getBoundingBox().intersectsRect(
                            Dust_Nail[i]->getBoundingBox())) {
                            
                                if (!isTool7AnimRunning) {
                                            isTool7AnimRunning = true;
                                            useTool[7]->runAction(animate);
                                        }
                                GLubyte opacity = Dust_Nail[i]->getOpacity();

                        if (opacity > 0) {
                            opacity = (opacity > 10) ? opacity - 10 : 0;
                            Dust_Nail[i]->setOpacity(opacity);
                            if (opacity == 0 ) {
                        pimplecount++;
                    }
                }
            }
            if (pimplecount >= 5) {
                pimplecount = 0;
                ToolNo = 8;
                moveToolFlag[7] = false;
                isTool7AnimRunning = false;
                useTool[7]->stopAllActions();
                useTool[7]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[7]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[7]->setOpacity(254);
                    }),nullptr));
                scheduleOnce(schedule_selector(ManicureView::toolComplete), 1.2);
            }
        }
        
    }
    
    if (moveToolFlag[8] == true) {
        useTool[8]->setPosition(location);
        moveDot->setPosition(Point(location.x-(SCALE_RATIO_X*5),location.y+(SCALE_RATIO_Y*115)));
        
        for (int i = 1; i <= 5; i++) {
            if (moveDot->getBoundingBox().intersectsRect(Brok_Nail[i]->getBoundingBox()) && Brok_Nail[i]->getOpacity() == 255) {
                Brok_Nail[i]->setOpacity(0);
                pimplecount++;
            }
            
        }
        if (pimplecount >= 5) {
            pimplecount = 0;
            ToolNo = 9;
            moveToolFlag[8] = false;
            useTool[8]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[8]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[8]->setOpacity(254);
            }),nullptr));
            scheduleOnce(schedule_selector(ManicureView::toolComplete), 1.2);
        }
    }
    if (popupMoveFlag[1] == true) {
        popupUseTool[1]->setPosition(location);
        moveDot->setPosition(Vec2(location.x-(SCALE_RATIO_X*55), location.y+(SCALE_RATIO_Y*155)));
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(vw_pimpledummy[i]->getBoundingBox()) && vw_pimpledummy[i]->getOpacity() == 0) {
                vw_pimpledummy[i]->setOpacity(1);
                pimpleNo = i;
                vw_pimple[i]->setTexture("pimple4.png");
                pimpledust[i]->runAction(Sequence::create(DelayTime::create(0.2),FadeIn::create(0.0), NULL));
                pimpleclean[i]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0.0),CallFunc::create([this]{
                    pimpledust[pimpleNo]->setOpacity(0);
                    pimplecount++;
                }), NULL));
            }
        }
        if (pimplecount >= 3) {
            pimplecount = 0;
            popupToolComplete = 1;
            popupMoveFlag[1] = false;
            popupUseTool[1]->setOpacity(254);
            popupUseTool[1]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),MoveTo::create(0.8,Vec2(SCALE_RATIO_X*1350,SCALE_RATIO_Y*288)),CallFunc::create([this]{for (int i = 1; i <= 3; i++) {
                vw_pimpledummy[i]->setOpacity(0);
            }}), NULL));
            scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 1.2);
        }
    }
    if (popupMoveFlag[2] == true) {
        popupUseTool[2]->setPosition(location);
        moveDot->setPosition(Vec2(location.x - (SCALE_RATIO_X * 30),
                                  location.y + (SCALE_RATIO_Y * 90)));
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(
                    pimplecleandummy[i]->getBoundingBox())) {

                GLubyte opacity = pimpleclean[i]->getOpacity();

                if (opacity > 0) {
                    opacity = (opacity > 20) ? opacity - 20 : 0;
                    pimpleclean[i]->setOpacity(opacity);
                    if (opacity == 0 ) {
                        pimplecount++;
                    }
                }
            }
            if (pimplecount >= 3) {
                pimplecount = 0;
                popupToolComplete = 2;
                popupMoveFlag[2] = false;
                popupUseTool[2]->setOpacity(254);
                popupUseTool[2]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),MoveTo::create(0.5,Vec2(SCALE_RATIO_X*1250,SCALE_RATIO_Y*288)), NULL));
                scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 1.2);
            }
        }
    }
    if (popupMoveFlag[3] == true) {
        popupUseTool[3]->setPosition(location);
        moveDot->setPosition(Vec2(location.x - (SCALE_RATIO_X * 45),
                                  location.y + (SCALE_RATIO_Y * 135)));
        for (int i = 1; i <= 3; i++) {
            if(moveDot->getBoundingBox().intersectsRect(vw_pimpledummy[i]->getBoundingBox()) && vw_pimpledummy[i]->getOpacity() == 0) {
                vw_pimpledummy[i]->setOpacity(1);
                vw_pimple[i]->runAction(Sequence::create(DelayTime::create(0.5),CallFunc::create([this,i]{vw_pimple[i]->setTexture("pimple1_3.png");}), NULL));
                
                pimplecount++;
            }
        }
        if (pimplecount >= 3) {
            for (int i = 1; i <= 3; i++) {
                vw_pimpledummy[i]->setOpacity(0);
            }
            pimplecount = 0;
            popupToolComplete = 3;
            popupMoveFlag[3] = false;
            popupUseTool[3]->setOpacity(254);
            popupUseTool[3]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),MoveTo::create(0.5,Vec2(SCALE_RATIO_X*1350,SCALE_RATIO_Y*288)), NULL));
            scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 1.2);

        }
    }
    if (popupMoveFlag[4] == true) {
        popupUseTool[4]->setPosition(location);
        moveDot->setPosition(Vec2(location.x - (SCALE_RATIO_X * 55),
                                  location.y + (SCALE_RATIO_Y * 140)));
          
            for (int i = 1; i <= 7; i++) {
                if (moveDot->getBoundingBox().intersectsRect(
                        vw_pimpledummy[i]->getBoundingBox())) {

                    GLubyte opacity = vw_pimple[i]->getOpacity();

                    if (opacity > 0) {
                        opacity = (opacity > 30) ? opacity - 30 : 0;
                        vw_pimple[i]->setOpacity(opacity);

                        // ✅ jab pimple fully clean ho jaye, tabhi count++
                        if (opacity == 0 ) {
                            pimplecount++;
                        }
                    }
                }
        }
        if (pimplecount >= 7) {
            pimplecount = 0;
            popupToolComplete = 4;
            popupMoveFlag[4] = false;
            popupUseTool[4]->setOpacity(254);
            for (int i = 1; i <= 8; i++) {
                pimple[i]->setPosition(OUTOFSCREEN);
            }
            popupUseTool[4]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),MoveTo::create(0.5,Vec2(SCALE_RATIO_X*1350,SCALE_RATIO_Y*288)), NULL));
            scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 1.7);

        }
    }
    
}
void ManicureView::onTouchEnded(Touch* touch, Event* event)
{
    
    Point location = this->convertToNodeSpace(touch->getLocation());
    SimpleAudioEngine::getInstance()->end();
    

    log("pimplecleandummy[%d]->setPosition(Vec2(%3.0f,%3.0f));",t,location.x,location.y);
   //>getOpacit log("whitecream[%d]->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",t,location.x,location.y);
    t++;

    
    if (moveToolFlag[1] == true)
    {
        moveToolFlag[1] = false;
        useTool[1]->runAction(
            Sequence::create(
                MoveTo::create(0.5, PanelTool[1]->getPosition()),
                MoveTo::create(0.0, outPosition),
                CallFunc::create([this]() {
                    PanelTool[1]->setOpacity(255);
                    startSoapHint();
                }),
                nullptr
            )
        );
    }
    if (moveToolFlag[2] == true) {
        moveToolFlag[2] = false;
        useTool[2]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[2]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
        PanelTool[2]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0), NULL));
    }
    if (moveToolFlag[3] == true) {
        moveToolFlag[3] = false;
        particle_Shower->setAutoRemoveOnFinish(true);
        particle_Shower->stopSystem();
        particle_Shower->setVisible(false);
        
        useTool[3]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[3]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
        PanelTool[3]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0), NULL));
    }
    
    if (moveToolFlag[4] == true){
        moveToolFlag[4] = false;
    useTool[4]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[4]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
    PanelTool[4]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0), NULL));
    }
    if (moveToolFlag[6] == true)
    {
        moveToolFlag[6] = false;
        useTool[6]->runAction(
            Sequence::create(
                MoveTo::create(0.5, PanelTool[6]->getPosition()),
                MoveTo::create(0.0, outPosition),
                CallFunc::create([this]() {
                    PanelTool[6]->setOpacity(255);
                    PanelTool[6]->setTexture("PanelTool6.png");
                }),
                nullptr
            )
        );
    }
    if (moveToolFlag[7] == true)
    {
        moveToolFlag[7] = false;
        useTool[7]->stopAllActions();

        useTool[7]->runAction(
            Sequence::create(
                MoveTo::create(0.5, PanelTool[7]->getPosition()),
                MoveTo::create(0.0, outPosition),
                CallFunc::create([this]() {
                    PanelTool[7]->setOpacity(255);
                }),
                nullptr
            )
        );
    }
    if (moveToolFlag[8] == true)
    {
        moveToolFlag[8] = false;
        useTool[8]->runAction(
            Sequence::create(
                MoveTo::create(0.5, PanelTool[8]->getPosition()),
                MoveTo::create(0.0, outPosition),
                CallFunc::create([this]() {
                    PanelTool[8]->setOpacity(255);
                }),
                nullptr
            )
        );
    }
    if (popupMoveFlag[1] == true){
        popupMoveFlag[1] = false;
    popupUseTool[1]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));
    
    }
    
    if (popupMoveFlag[2] == true){
        popupMoveFlag[2] = false;
    popupUseTool[2]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));
    }
    
    if (popupMoveFlag[3] == true){
        popupMoveFlag[3] = false;
    popupUseTool[3]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));
    }
    if (popupMoveFlag[4] == true){
        popupMoveFlag[4] = false;
    popupUseTool[4]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));
    }
}
void ManicureView::toolComplete(float d){
    
    if (ToolNo == 0) {
        PanelTool[1]->setOpacity(255);
    }
    if (ToolNo == 1) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[2]->setOpacity(255);
    }
    if (ToolNo == 2) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[3]->setOpacity(255);
    }
    if (ToolNo == 3) {
     
//        PanelTool[1]->runAction(Sequence::create(MoveTo::create(0.3, Vec2(toolpos[1].x,SCALE_RATIO_Y*-120)), NULL));
//        PanelTool[2]->runAction(Sequence::create(MoveTo::create(0.3, Vec2(toolpos[2].x,SCALE_RATIO_Y*-120)), NULL));
//        PanelTool[3]->runAction(Sequence::create(MoveTo::create(0.3, Vec2(toolpos[3].x,SCALE_RATIO_Y*-120)), NULL));
//
//        PanelTool[4]->runAction(Sequence::create(DelayTime::create(0.3),MoveTo::create(0.3, toolpos[4]),FadeIn::create(0.0), NULL));
//        PanelTool[5]->runAction(Sequence::create(DelayTime::create(0.3),MoveTo::create(0.6, toolpos[5]), NULL));
//        PanelTool[6]->runAction(Sequence::create(DelayTime::create(0.3),MoveTo::create(0.9, toolpos[6]), NULL));
        
        float outY = -120 * SCALE_RATIO_Y;

        for (int i = 1; i <= 3; i++)
        {
            PanelTool[i]->runAction(
                EaseSineIn::create(
                    MoveTo::create(0.25f, Vec2(toolpos[i].x, outY))
                )
            );
        }
        
        float delay = 0.0f;

        for (int i = 4; i <= 6; i++)
        {
            PanelTool[i]->setOpacity(255); // safety

            PanelTool[i]->runAction(
                Sequence::create(
                    DelayTime::create(delay),
                    EaseBackOut::create(
                        MoveTo::create(0.35f, toolpos[i])
                    ),
                    nullptr
                )
            );

            delay += 0.12f;   // perfect stagger timing
        }


    }
    if (ToolNo == 4) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[5]->setOpacity(255);
    }
    if (ToolNo == 5) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[6]->setOpacity(255);
    }
    if (ToolNo == 6) {
        whitecreamFlag = true;
    }
    if (ToolNo == 7) {
     
        PanelTool[4]->runAction(Sequence::create(MoveTo::create(0.3, Vec2(toolpos[4].x,SCALE_RATIO_Y*-120)), NULL));
        PanelTool[5]->runAction(Sequence::create(MoveTo::create(0.3, Vec2(toolpos[5].x,SCALE_RATIO_Y*-120)), NULL));
        PanelTool[6]->runAction(Sequence::create(MoveTo::create(0.3, Vec2(toolpos[6].x,SCALE_RATIO_Y*-120)), NULL));

        PanelTool[7]->runAction(Sequence::create(DelayTime::create(0.3),MoveTo::create(0.3, toolpos[7]),FadeIn::create(0.0), NULL));
        PanelTool[8]->runAction(Sequence::create(DelayTime::create(0.3),MoveTo::create(0.6, toolpos[8]), NULL));

    }
    if (ToolNo == 8) {
        PanelTool[8]->setOpacity(255);
    }
    if (ToolNo == 9) {
    }
}
void ManicureView::popuptoolComplete(float d)
{
    if (popupToolComplete == 1) {
        popupUseTool[2]->runAction(Sequence::create(MoveTo::create(1.0, Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));

    }
    if (popupToolComplete == 2) {
        popupUseTool[3]->runAction(Sequence::create(MoveTo::create(1.0, Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));
   }
    if (popupToolComplete == 3) {
        popupUseTool[4]->runAction(Sequence::create(MoveTo::create(1.0, Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),FadeIn::create(0.0), NULL));

    }
    if (popupToolComplete == 4) {
        vw_pop->runAction(Sequence::create(DelayTime::create(0.5),ScaleTo::create(0.5, SCALE_RATIO_X*0, SCALE_RATIO_Y*0),CallFunc::create([this]{black_M_bg->setVisible(false);}), NULL));
        
        vw_hand->runAction(Sequence::create(DelayTime::create(0.5),ScaleTo::create(0.5, SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0), NULL));
        isPopupFlag = false;
        ToolNo = 5;
        scheduleOnce(schedule_selector(ManicureView::toolComplete), 1.2);

    }

}
void ManicureView::openPopupView()
{
    vw_pop = Sprite::create("pimple_popup.png");
    vw_pop->setPosition(Vec2(386*SCALE_RATIO_X,523*SCALE_RATIO_Y));
    vw_pop->setScale(SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0);
    this->addChild(vw_pop);

    vw_hand = Sprite::create(__String::createWithFormat("p_hand_%d.png",handNo)->getCString());
    vw_hand->setPosition(Vec2(386*SCALE_RATIO_X,523*SCALE_RATIO_Y));
    vw_hand->setScale(SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0);
    this->addChild(vw_hand);

    
    //set Pimple
    {
        for (int i = 1; i <= 7; i++) {
            vw_pimpledummy[i] = Sprite::create("pimple1_1.png");
            vw_pimpledummy[i]->setScale(SCALE_RATIO_X*1.0,SCALE_RATIO_Y*1.0);
            this->addChild(vw_pimpledummy[i]);
            vw_pimpledummy[i]->setOpacity(0);
        }
        vw_pimpledummy[1]->setPosition(Vec2(443*SCALE_RATIO_X,531*SCALE_RATIO_Y));
        vw_pimpledummy[2]->setPosition(Vec2(318*SCALE_RATIO_X,482*SCALE_RATIO_Y));
        vw_pimpledummy[3]->setPosition(Vec2(274*SCALE_RATIO_X,590*SCALE_RATIO_Y));
        vw_pimpledummy[4]->setPosition(Vec2(320*SCALE_RATIO_X,602*SCALE_RATIO_Y));
        vw_pimpledummy[5]->setPosition(Vec2(327*SCALE_RATIO_X,416*SCALE_RATIO_Y));
        vw_pimpledummy[6]->setPosition(Vec2(467*SCALE_RATIO_X,474*SCALE_RATIO_Y));
        vw_pimpledummy[7]->setPosition(Vec2(438*SCALE_RATIO_X,657*SCALE_RATIO_Y));

        for (int i = 1; i <= 3; i++) {
            vw_pimple[i] = Sprite::create("pimple1_1.png");
            vw_hand->addChild(vw_pimple[i]);
            if (i == 1)
                vw_pimple[i]->setScale(1.0);
            else if (i == 2)
                vw_pimple[i]->setScale(0.7,0.7);
            else if (i == 3)
                vw_pimple[i]->setScale(0.4,0.4);
        }
        for (int i = 4; i <= 5; i++) {
            vw_pimple[i] = Sprite::create("pimple5.png");
            vw_hand->addChild(vw_pimple[i]);
            if (i == 4)
                vw_pimple[i]->setScale(0.9,0.9);
            else if (i == 5)
                vw_pimple[i]->setScale(0.6,0.6);
        }
        for (int i = 6; i <= 7; i++) {
            vw_pimple[i] = Sprite::create("pimple4.png");
            vw_hand->addChild(vw_pimple[i]);
            vw_pimple[i]->setScale(1.0);
        }
        vw_pimple[1]->setPosition(Vec2(227,187));
        vw_pimple[2]->setPosition(Vec2(102,140));
        vw_pimple[3]->setPosition(Vec2( 58,248));
        vw_pimple[4]->setPosition(Vec2(107,259));
        vw_pimple[5]->setPosition(Vec2(113, 75));
        vw_pimple[6]->setPosition(Vec2(252,131));
        vw_pimple[7]->setPosition(Vec2(223,315));
        
        for (int i = 1; i <= 3; i++) {
            pimpledust[i] = Sprite::create("pimple2.png");
            vw_hand->addChild(pimpledust[i]);
            pimpledust[i]->setScale(1);
            pimpledust[i]->setOpacity(0);
            
            pimpleclean[i] = Sprite::create("pimple3.png");
            vw_hand->addChild(pimpleclean[i]);
            pimpleclean[i]->setOpacity(0);

        }
        pimpledust[3]->setScale(0.4,0.4);
        pimpleclean[3]->setScale(0.5,0.5);

        pimpledust[2]->setFlippedX(true);
        pimpledust[3]->setFlippedX(true);

        pimpledust[1]->setPosition(Vec2(211,196));
        pimpledust[2]->setPosition(Vec2(114,150));
        pimpledust[3]->setPosition(Vec2( 62,248));

        pimpleclean[1]->setPosition(Vec2(197,184));
        pimpleclean[2]->setPosition(Vec2(127,141));
        pimpleclean[3]->setPosition(Vec2( 68,244));
        
        for (int i = 1; i <= 3; i++) {
            
            pimplecleandummy[i] = Sprite::create("pimple3.png");
            pimplecleandummy[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            this->addChild(pimplecleandummy[i]);
            pimplecleandummy[i]->setOpacity(0);

        }
        pimplecleandummy[1]->setPosition(Vec2(SCALE_RATIO_X*413,SCALE_RATIO_Y*526));
        pimplecleandummy[2]->setPosition(Vec2(SCALE_RATIO_X*342,SCALE_RATIO_Y*483));
        pimplecleandummy[3]->setPosition(Vec2(SCALE_RATIO_X*287,SCALE_RATIO_Y*582));

        
    }
    

}
void ManicureView::setCoinPanel(){
   
    coinpanel = Sprite::create("coin button.png");
    coinpanel->setPosition(Vec2(475*SCALE_RATIO_X,740*SCALE_RATIO_Y));
    coinpanel->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(coinpanel,5);

    coin_icon = Sprite::create("coin.png");
    coin_icon->setPosition(Vec2(455*SCALE_RATIO_X,739*SCALE_RATIO_Y));
    coin_icon->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(coin_icon,5);

    CoinText = Label::createWithTTF(
        StringUtils::format("%d", CoinManager::getCoins()),
        "fonts/Marker Felt.ttf",
        10
    );
    CoinText->setAnchorPoint(Vec2(0, 0.5f));
    CoinText->setPosition(Vec2(39, coinpanel->getContentSize().height / 2));
    CoinText->setColor(Color3B::BLACK);
    coinpanel->addChild(CoinText);
    
//    g_coins = UserDefault::getInstance()->getIntegerForKey("TOTAL_COINS", 1000);

}
void ManicureView::playCoinFly(Vec2 startPos, int coinCount)
{
    int flyCoins = 10;   // number of flying coins
    Vec2 endPos = coinpanel->getPosition();

    
    for (int i = 0; i < flyCoins; i++)
    {
        auto coin = Sprite::create("coin.png");
        coin->setPosition(startPos);
        coin->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
        this->addChild(coin, 20);

        float delay = i * 0.05f;

        // random curve offset
        Vec2 midPoint = startPos +
            Vec2(random(-100, 100), random(50, 150));

        auto bezier = BezierTo::create(
            0.6f,
            {
                startPos,
                midPoint,
                endPos
            }
        );

        auto action = Sequence::create(
            DelayTime::create(delay),
            Spawn::create(
                bezier,
                ScaleTo::create(0.6f, SCALE_RATIO_XY*0.3f),
                FadeOut::create(0.6f),
                nullptr
            ),
            RemoveSelf::create(),
            nullptr
        );

        coin->runAction(action);
    }

    Animation* tempAnim = Animation::create();
    tempAnim->addSpriteFrameWithFile("coinAnim1.png");
    tempAnim->addSpriteFrameWithFile("coinAnim2.png");
    tempAnim->addSpriteFrameWithFile("coinAnim3.png");
    tempAnim->addSpriteFrameWithFile("coinAnim4.png");
    tempAnim->addSpriteFrameWithFile("coinAnim3.png");
    tempAnim->addSpriteFrameWithFile("coinAnim2.png");
    tempAnim->addSpriteFrameWithFile("coinAnim1.png");
    tempAnim->addSpriteFrameWithFile("coin.png");
    tempAnim->setDelayPerUnit(0.1f);

    Animate* animate = Animate::create(tempAnim);

    coin_icon->runAction(animate);

    // update coins after animation
    this->runAction(
        Sequence::create(
            DelayTime::create(0.8f),
            CallFunc::create([=]() {
                CoinManager::addCoins(coinCount);
                CoinText->setString(
                    StringUtils::format("%d", CoinManager::getCoins())
                );

                // label bounce
                CoinText->runAction(
                    Sequence::create(
                        ScaleTo::create(0.1f, 1.2f),
                        ScaleTo::create(0.1f, 1.0f),
                        nullptr
                    )
                );
            }),
            nullptr
        )
    );
}
void ManicureView::startSoapHint()
{
    if (!handHint)
        return;

    handHint->stopAllActions();

    int targetIndex = -1;

    // find first incomplete soap
    for (int i = 1; i <= 3; i++)
    {
        if (!soapDone[i])
        {
            targetIndex = i;
            break;
        }
    }

    if (targetIndex == -1)
    {
        handHint->setVisible(false);
        return;
    }

    handHint->setVisible(true);

    
    Vec2 startPos = Vec2(SCALE_RATIO_X*305,SCALE_RATIO_Y*312);
    Vec2 endPos   = soapHintPos[targetIndex];

    CCLOG("startPos = %3.0f.%3.0f",startPos.x,startPos.y);
    CCLOG("endPos = %3.0f.%3.0f",endPos.x,endPos.y);

    handHint->setPosition(startPos);

    // move panel → soap
    auto moveToSoap = MoveTo::create(1.0f, endPos);

    // tap animation
    auto tapDown = MoveBy::create(0.25f, Vec2(0, -15));
    auto tapUp   = MoveBy::create(0.25f, Vec2(0, 15));

    auto tapTwice = Sequence::create(
        tapDown, tapUp,
        tapDown, tapUp,
        nullptr
    );

    // reset position back to panel
    auto resetPos = CallFunc::create([=]() {
        handHint->setPosition(startPos);
    });

    // 🔁 FULL LOOP
    auto fullHintLoop = RepeatForever::create(
        Sequence::create(
            moveToSoap,
            DelayTime::create(0.5f),
            resetPos,
            DelayTime::create(0.2f),
            nullptr
        )
    );

    handHint->runAction(fullHintLoop);
}



