//
//  ManicureView.hpp
//  demo
//
//  Created by Pritesh on 05/01/26.
//

#ifndef ManicureView_hpp
#define ManicureView_hpp

#include <stdio.h>
#include "cocos2d.h"
#include "HandIndication.hpp"

using namespace cocos2d;

class ManicureView : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    int t;
    
    Size visibleSize;
    
    virtual bool init();
    
    CREATE_FUNC(ManicureView);
    
    virtual bool onTouchBegan(cocos2d::Touch*, cocos2d::Event*);
    virtual void onTouchEnded(cocos2d::Touch*, cocos2d::Event*);
    virtual void onTouchMoved(cocos2d::Touch*, cocos2d::Event*);

    Sprite *btn_home;
    Sprite *M_bg,*black_M_bg, *hand;
    Sprite *handDust[5];
    Sprite *handFullDust;
    Sprite *handDotDust[5];
    Sprite *Brok_Nail[6];
    Sprite *Dust_Nail[6];

    Sprite *pimple[10];
    
    Sprite *panel;
    Sprite *PanelTool[10];
    Vec2 toolpos[10];
    
    Vec2 soapToolPos;
    Vec2 soapHintPos[4];   // index 1..3
    Sprite* handHint;
    bool soapDone[4];   // index 1..3
    int currentSoapHint;
    void startSoapHint();
    
    // openextraView
    Sprite *vw_pop;
    Sprite *vw_hand;
    Sprite *vw_pimple[10];
    Sprite *vw_pimpledummy[10];
    Sprite *pop1_demo;
    Sprite *bubble[30];
    Sprite *pinksoap[5];
    Sprite *pinksoapdummy[5];

    Sprite *whitecream[5];
    
    Sprite *useTool[10];
    Sprite *showerpipe;
    
    Sprite *popupUseTool[5];
    Sprite *moveDot;
    
    
    Vec2 outPosition;
    bool moveToolFlag[10];
    int soapcnt;
    int bubblecnt;
    bool isbubble11;
    int ToolNo;
    
    
    void Setup_View();
    void Setup_Panel();
    void openPopupView();
    void toolComplete(float d);
    void popuptoolComplete(float d);

    int pimpleNo;
    int pimplecount;
    int popupToolComplete;
    Sprite *coinpanel;
    Sprite *coin_icon;
    Label *CoinText;
    void setCoinPanel();
    void playCoinFly(Vec2 startPos, int coinCount);
    
    bool isPopupFlag;
    bool popupMoveFlag[6];
    
    Sprite *pimpledust[5];
    Sprite *pimpleclean[5];
    
    Sprite *pimplecleandummy[5];
    bool whitecreamFlag;
    
    
    ParticleSystemQuad *particle_Shower;
};
#endif /* ManicureView_hpp */
