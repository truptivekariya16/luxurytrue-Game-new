//
//  CoinManager.hpp
//  demo
//
//  Created by Pritesh on 10/01/26.
//

#ifndef CoinManager_hpp
#define CoinManager_hpp

#include <stdio.h>
#pragma once
class CoinManager
{
public:
    static int getCoins();
    static void addCoins(int value);
    static void spendCoins(int value);
};

#endif /* CoinManager_hpp */
