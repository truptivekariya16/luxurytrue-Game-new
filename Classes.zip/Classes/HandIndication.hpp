#ifndef __HAND_INDICATION_H__
#define __HAND_INDICATION_H__

#include "cocos2d.h"
USING_NS_CC;

class HandIndication : public Node
{
public:
    static HandIndication* create(const std::vector<Vec2>& positions);

    virtual bool init(const std::vector<Vec2>& positions);

    // mark soap applied at index
    void markCompleted(int index);

    // start hand movement
    void startHint();

    // stop all hints
    void stopHint();

private:
    Sprite* hand;
    std::vector<Vec2> hintPositions;
    std::vector<bool> isCompleted;

    int currentIndex;

    void moveToNextValidPosition();
};

#endif
