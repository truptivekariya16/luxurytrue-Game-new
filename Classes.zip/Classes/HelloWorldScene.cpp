//
//  HelloWorldScene.cpp
//  demo-mobile
//
//  Created by Pritesh on 05/01/26.
//

#include "Header.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

bool HelloWorld::init()
{
    if (!Scene::init())
        return false;

    auto visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();

    auto bg = Sprite::create("bg.png");
    bg->setAnchorPoint(Vec2(0.5f, 0.5f));
    bg->setPosition(origin + visibleSize / 2);
    float scaleX = visibleSize.width  / bg->getContentSize().width;
    float scaleY = visibleSize.height / bg->getContentSize().height;
    bg->setScale(scaleX, scaleY);
    this->addChild(bg, -1);

    
    float SCALEX = visibleSize.width  / 768.0f;
    float SCALEY = visibleSize.height / 1024.0f;

    
    float finalScale = MIN(SCALEX, SCALEY);

    CCLOG("finalScale %3.0f",finalScale);
    
    auto mySprite = Sprite::create("Home.png");
    mySprite->setAnchorPoint(Vec2(0.5f, 0.5f));
    mySprite->setPosition(Point(700,950));
    CCLOG("setPosition %3.0f %3.0f",mySprite->getPosition().x,mySprite->getPosition().y);
    

    if (isIphone == true)
        mySprite->setScale(SCALEXY);
    else
        mySprite->setScale(SCALEXY);

    this->addChild(mySprite);
    return true;
}
