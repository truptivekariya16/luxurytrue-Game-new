//
//  Macro.h
//  MyGame
//
//  Created by Pritesh on 05/01/26.
//
//

#ifndef Macro_h
#define Macro_h


#define OUTOFSCREEN     Vec2(100000,10000)
//print points
#define PRINT_POINTS(POINT)     log("\n%1f*POSX,%1f*POSY",POINT.x,POINT.y);

////Get The IPad Screen size
#define IPAD_SCREEN_SIZE        Director::getInstance()->getWinSize()

#define IPAD_ORG_WIDTH (Director::getInstance()->getWinSize().width < Director::getInstance()->getWinSize().height ? 768 : 1024)

#define IPAD_ORG_HEIGHT (Director::getInstance()->getWinSize().width > Director::getInstance()->getWinSize().height ? 768 : 1024)

//Get The Ipad screen height  width

#define IPAD_WIDTH              Director::getInstance()->getWinSize().width

#define IPAD_HEIGHT              Director::getInstance()->getWinSize().height

#define SCALE_RATIO_X (IPAD_WIDTH / IPAD_ORG_WIDTH)

#define SCALE_RATIO_Y (IPAD_HEIGHT / IPAD_ORG_HEIGHT)

#define SCALE_RATIO_XY ((IPAD_WIDTH / IPAD_ORG_WIDTH) + (IPAD_HEIGHT / IPAD_ORG_HEIGHT) / 2)

#define RAND_UINT() arc4random()

#endif /* Macro_h */
