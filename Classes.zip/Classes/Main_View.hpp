//
//  Main_View.hpp
//  demo
//
//  Created by Pritesh on 20/01/26.
//

#ifndef Main_View_hpp
#define Main_View_hpp

#include <stdio.h>
#include "cocos2d.h"

class Main_View : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();
    
    virtual bool init();

    // macro to enable create()
    CREATE_FUNC(Main_View);
    
    virtual bool onTouchBegan(cocos2d::Touch*, cocos2d::Event*);
    virtual void onTouchEnded(cocos2d::Touch*, cocos2d::Event*);
    virtual void onTouchMoved(cocos2d::Touch*, cocos2d::Event*);
    
    Sprite *M_bg, *btn_play , *img_Girl , *img_3, *hand , *face;
    
    void Setup_View();
};

#endif // __MY_SCENE_H__
