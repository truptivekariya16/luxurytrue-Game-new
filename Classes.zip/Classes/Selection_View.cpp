//
//  Selection_View.cpp
//  demo
//
//  Created by Pritesh on 05/01/26.
//

#include "Header.h"
Scene* Selection_View::createScene()
{
    return Selection_View::create();
}


bool Selection_View::init()
{
    if (!Scene::init())
        return false;
    
    t = 6;
//    auto visibleSize = Director::getInstance()->getVisibleSize();
//    auto origin = Director::getInstance()->getVisibleOrigin();

    M_bg = Sprite::create("M_bg.png");
    M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(M_bg);
    
    black_M_bg = Sprite::create("blackbg.png");
    black_M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    black_M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(black_M_bg);
    
    
    auto touchListener = EventListenerTouchOneByOne::create();
    
    touchListener->onTouchBegan = CC_CALLBACK_2(Selection_View::onTouchBegan, this);
    touchListener->onTouchEnded = CC_CALLBACK_2(Selection_View::onTouchEnded, this);
    touchListener->onTouchMoved = CC_CALLBACK_2(Selection_View::onTouchMoved, this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

    this->setScale(2.0);
    
    Setup_View();
    
    return true;
}
void Selection_View::Setup_View(){
        
    for (int i = 1; i <= 4; i++) {
        
        select_box[i] = Sprite::create("s_popup2.png");
        select_box[i]->setPosition(Vec2(1384*SCALE_RATIO_X,522*SCALE_RATIO_Y));
        select_box[i]->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
        this->addChild(select_box[i]);
        

        select_border[i] = Sprite::create("s_popup1.png");
        select_border[i]->setPosition(Vec2(130,170));
        select_border[i]->setScale(1.0);
        select_box[i]->addChild(select_border[i]);

        
        hand_select[i] = Sprite::create(__String::createWithFormat("select%d_%d.png",ishand,i)->getCString());
        hand_select[i]->setScale(1.0);
        hand_select[i]->setPosition(Vec2(145,170));
        select_box[i]->addChild(hand_select[i]);
        
    }
    select_box[1]->setScale(SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0);
    select_box[1]->setPosition(Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y));

    nextBtn = Sprite::create("nextprev.png");
    nextBtn->setPosition(Vec2(545*SCALE_RATIO_X,516*SCALE_RATIO_Y));
    nextBtn->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(nextBtn);
    nextBtn->setOpacity(0);

    prevBtn = Sprite::create("nextprev.png");
    prevBtn->setPosition(Vec2(220*SCALE_RATIO_X,516*SCALE_RATIO_Y));
    prevBtn->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(prevBtn);
    prevBtn->setFlippedX(true);
    prevBtn->setOpacity(0);
    
    
    select_box[1]->runAction(Sequence::create(ScaleTo::create(1.0, SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0), NULL));
    
    nextBtn->runAction(Sequence::create(DelayTime::create(1.0),FadeIn::create(0.0), NULL));


}
bool Selection_View::onTouchBegan(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    //handDust[t]->setPosition(location);
    
    
    for (int i = 1; i <= 4; i++) {
        if (select_box[i]->getBoundingBox().containsPoint(location) && select_box[i]->getOpacity() == 255) {
            select_box[i]->setOpacity(254);
            handNo = i;
            Director::getInstance()->replaceScene(ManicureView::createScene());
        }
    }
    
    if(nextBtn->getBoundingBox().containsPoint(location) && nextBtn->getOpacity()==255){
        UIButtonSFX
        nextBtn->setOpacity(0);
        prevBtn->setOpacity(0);
        nextprevcnt++;
       CCLOG("NEXTPREV %d",nextprevcnt);
        
        if(nextprevcnt == 1){
            select_box[1]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(-184*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            select_box[2]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            nextBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1), NULL));
            prevBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1), NULL));
        }
        else if(nextprevcnt == 2){
            nextBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            prevBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            
            select_box[2]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(-184*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            select_box[3]->runAction(Sequence::create(DelayTime::create(0.5),MoveTo::create(0.5, Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
        }
        else if(nextprevcnt == 3){
            prevBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            select_box[3]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(-184*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            select_box[4]->runAction(Sequence::create(DelayTime::create(0.5),MoveTo::create(0.5, Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
        }
        else{
            nextprevcnt = 3;
        }
    }
    if(prevBtn->getBoundingBox().containsPoint(location) && prevBtn->getOpacity()==255){
        UIButtonSFX
        nextBtn->setOpacity(0);
        prevBtn->setOpacity(0);
        nextprevcnt--;
       CCLOG("NEXTPREV %d",nextprevcnt);
        
        if(nextprevcnt == 0){
            select_box[1]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            select_box[2]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(1384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            nextBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1), NULL));
        }
        else if(nextprevcnt == 1){
            nextBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            prevBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            select_box[2]->runAction(Sequence::create(DelayTime::create(0.5),MoveTo::create(0.5, Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            select_box[3]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(1384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
        }
        else if(nextprevcnt == 2){
            nextBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            prevBtn->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(1.0), NULL));
            select_box[3]->runAction(Sequence::create(DelayTime::create(0.5),MoveTo::create(0.5, Vec2(384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
            select_box[4]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(1384*SCALE_RATIO_X,522*SCALE_RATIO_Y)), NULL));
        }
        else{
            nextprevcnt = 0;
        }
    }
    
    return true;
}
void Selection_View::onTouchMoved(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    //select_border[1]->setPosition(location);
}
void Selection_View::onTouchEnded(Touch* touch, Event* event)
{
    
    Point location = this->convertToNodeSpace(touch->getLocation());
  //  log("select_border[1]->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",location.x,location.y);
   // log("hand_select[%d]->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",t,location.x,location.y);

    t++;
}
