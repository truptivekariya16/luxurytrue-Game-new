//
//  Header.h
//  MyGame
//
//  Created by Dhaval Parmar on 03/11/17.
//
//

#ifndef Header_h
#define Header_h

#include "audio/include/SimpleAudioEngine.h"
using namespace CocosDenshion;


#include "cocos2d.h"
#include "Macro.h"
#include "AppDelegate.h"
#include "audio/include/SimpleAudioEngine.h"
#include "HelloWorldScene.hpp"
#include "ManicureView.hpp"
#include "Selection_View.hpp"
#include "HandIndication.hpp"
#include "CoinManager.hpp"
#include "Main_View.hpp"
#include "AudioEngine.h"
using namespace cocos2d::experimental;


#define SAD_EXPRESSION BG->runAction(RepeatForever::create(Sequence::create(DelayTime::create(3),CallFunc::create([this]{    AudioEngine::play2d(StringUtils::format("Char_Sad_SFX%d.mp3",random(1,10)).c_str(),false,MUSIC);}),DelayTime::create(4),NULL)));

#define HAPPY_EXPRESSION BG->runAction(RepeatForever::create(Sequence::create(DelayTime::create(3),CallFunc::create([this]{    AudioEngine::play2d(StringUtils::format("Char_Happy_SFX%d.mp3",random(1,10)).c_str(),false,MUSIC);}),DelayTime::create(4),NULL)));

#define TapEffectSimple Sequence::create(ScaleTo::create(0.1, 0.9),ScaleTo::create(0.15, 1), NULL)
#define TapEffect Sequence::create(ScaleTo::create(0.2, 0.7),EaseElasticOut::create(ScaleTo::create(0.5, 1)), NULL)
#define MoreAppEffect RepeatForever::create(Sequence::create(Spawn::create(JumpBy::create(1.0, Vec2(0,0), 5, 2), Sequence::create(ScaleTo::create(0.3, 0.9, 1.0),ScaleTo::create(0.3, 1.0, 0.9),ScaleTo::create(0.3, 1.0),NULL),NULL) ,DelayTime::create(1.5), NULL))

#define MORE_BUTTON_POSITION Point(180-BtnPosI5, 700)
#define LEVEL_BUTTON_POSITION Point(60-BtnPosI5, 700)
#define NEXT_BUTTON_POSITION Point(960+BtnPosI5, 700)

#define LEVEL_BUTTON_TAP UIButtonSFX Level_Btn->setOpacity(254);Level_Btn->runAction(Sequence::create(TapEffect, CallFunc::create([this]{AudioEngine::pauseAll();Director::getInstance()->pushScene(Ad_Popup::createScene());}), FadeTo::create(0.0, 255), NULL));

#define NextButtonVisible Next_Btn->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create([this](){Next_Btn->setPosition(NEXT_BUTTON_POSITION);Next_Btn->setOpacity(255);Next_Btn->runAction(RepeatForever::create(TapEffect));}), NULL));

#define play_Sound(fileName, loop) AudioEngine::play2d(fileName, loop, MUSIC)
#define EntrySFX AudioEngine::play2d("entry_sfx.mp3", false, MUSIC);
#define ExitSFX AudioEngine::play2d("exit_sfx.mp3", false, MUSIC);
//#define OUTOFSCREEN Vec2(100000, 100000)
#define UIButtonSFX AudioEngine::play2d("Other button.mp3", false, MUSIC);
#define ToolTapSound AudioEngine::play2d("Tap Button.mp3", false, MUSIC);
#define ShowerSound AudioEngine::play2d("0805.mp3", false, MUSIC);

#define PhaseCompletionParticle {this->runAction(Sequence::create( CallFunc::create([this](){switch (random(1, 2)){case 1:AudioEngine::play2d("vac_snd_8.mp3", false, MUSIC);break;case 2:AudioEngine::play2d("vac_snd_9.mp3", false, MUSIC);break;}AudioEngine::play2d("Level Complete particle.mp3", false, MUSIC);ParticleSystemQuad *PC_Particle[20];for (int i=1; i<=3; i++){PC_Particle[i] = ParticleSystemQuad::create(StringUtils::format("PC_Particle%i.plist", i));PC_Particle[i]->setPosition(Vec2(512, 384));this->addChild(PC_Particle[i],500);}}), NULL));}

#define NEXT_BUTTON_TAP LEVEL_NO=2; SimpleAudioEngine::getInstance()->stopAllEffects();Next_Btn->stopAllActions();_eventDispatcher->setEnabled(false);Next_Btn->setOpacity(254); UIButtonSFX Next_Btn->runAction(TapEffect);Director::getInstance()->replaceScene(TransitionFade::create(0.5, LoadingScreen::createScene()));

#define SCALE_EFFECT_SOUND CallFunc::create([this](){AudioEngine::play2d("HO_020920_ScaleEffect_SFX.mp3", false, MUSIC);})
#define ENTRY_SOUND CallFunc::create([this](){if (MUSIC==1) {EntrySFX}})
#define EXIT_SOUND CallFunc::create([this](){if (MUSIC==1) {ExitSFX}})

#define ZOOM_IN CallFunc::create([this](){ AudioEngine::play2d("ZoomIn2.mp3", false, MUSIC); })
#define ZOOM_OUT CallFunc::create([this](){ AudioEngine::play2d("ZoomOut1.mp3", false, MUSIC); })


#define VIEWSCALEMACRO AppDelegate::GetBannerHeight(this);this->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1),(ActionInterval*)CallFunc::create(CC_CALLBACK_0(AppDelegate::GetBannerHeight,this)),NULL)));this->setTag(1000);


#endif /* Header_h */
