//
//  Main_View.cpp
//  demo
//
//  Created by Pritesh on 20/01/26.
//

#include "Header.h"

USING_NS_CC;

Scene* Main_View::createScene()
{
    return Main_View::create();
}

bool Main_View::init()
{
    if (!Scene::init())
    {
        return false;
    }
    M_bg = Sprite::create("bg-2.png");
    //M_bg = Sprite::create("main sc reen.png");
    M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(M_bg);
    
    Setup_View();
    
    this->setScale(2.0);
    
    auto touchListener = EventListenerTouchOneByOne::create();
    
    touchListener->onTouchBegan = CC_CALLBACK_2(Main_View::onTouchBegan, this);
    touchListener->onTouchEnded = CC_CALLBACK_2(Main_View::onTouchEnded, this);
    touchListener->onTouchMoved = CC_CALLBACK_2(Main_View::onTouchMoved, this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
    
    return true;
}
void Main_View::Setup_View()
{
    btn_play = Sprite::create("play.png");
    btn_play->setPosition(Vec2(465*SCALE_RATIO_X,498*SCALE_RATIO_Y));
    btn_play->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(btn_play);
    
    img_Girl = Sprite::create("girl_1.png");
    img_Girl->setPosition(Vec2(297*SCALE_RATIO_X,435*SCALE_RATIO_Y));
    img_Girl->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(img_Girl);
    
    hand = Sprite::create("hand.png");
    hand->setPosition(Vec2(306*SCALE_RATIO_X,469*SCALE_RATIO_Y));
    hand->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(hand);
    
    face = Sprite::create("face.png");
    face->setPosition(Vec2(245*SCALE_RATIO_X,517*SCALE_RATIO_Y));
    face->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(face);
    
    img_3 = Sprite::create("3.png");
    img_3->setPosition(Vec2(370*SCALE_RATIO_X,423*SCALE_RATIO_Y));
    img_3->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(img_3);
    
    
}
bool Main_View::onTouchBegan(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    if(btn_play->getBoundingBox().containsPoint(location) && btn_play->getOpacity() == 255){
        btn_play->setOpacity(254);
        UIButtonSFX
        Director::getInstance()->replaceScene(ManicureView::create());
    }
    return true;
}
void Main_View::onTouchMoved(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    //select_border[1]->setPosition(location);
    img_3->setPosition(location);
}
void Main_View::onTouchEnded(Touch* touch, Event* event)
{
    
    Point location = this->convertToNodeSpace(touch->getLocation());
  //  log("select_border[1]->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",location.x,location.y);
    
    log("img_3->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",location.x,location.y);

   // t++;
}
