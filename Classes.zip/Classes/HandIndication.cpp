#include "Header.h"

HandIndication* HandIndication::create(const std::vector<Vec2>& positions)
{
    HandIndication* ret = new HandIndication();
    if (ret && ret->init(positions))
    {
        ret->autorelease();
        return ret;
    }
    CC_SAFE_DELETE(ret);
    return nullptr;
}

bool HandIndication::init(const std::vector<Vec2>& positions)
{
    if (!Node::init()) return false;

    hintPositions = positions;
    isCompleted.resize(positions.size(), false);
    currentIndex = -1;

    hand = Sprite::create("indi_hand.png");
    hand->setAnchorPoint(Vec2(0.5f, 1.0f));
    addChild(hand);

    return true;
}

void HandIndication::startHint()
{
    moveToNextValidPosition();
}

void HandIndication::stopHint()
{
    hand->stopAllActions();
    hand->setVisible(false);
}

void HandIndication::markCompleted(int index)
{
    if (index >= 0 && index < isCompleted.size())
    {
        isCompleted[index] = true;

        // agar current wahi tha to next pe le jao
        if (index == currentIndex)
        {
            moveToNextValidPosition();
        }
    }
}

void HandIndication::moveToNextValidPosition()
{
    hand->stopAllActions();

    int total = hintPositions.size();
    bool found = false;

    for (int i = 0; i < total; i++)
    {
        int next = (currentIndex + 1 + i) % total;
        if (!isCompleted[next])
        {
            currentIndex = next;
            found = true;
            break;
        }
    }

    if (!found)
    {
        // sab complete ho gaye
        hand->setVisible(false);
        return;
    }

    hand->setVisible(true);
    hand->setPosition(hintPositions[currentIndex]);

    auto up = MoveBy::create(0.5f, Vec2(SCALE_RATIO_X*0, SCALE_RATIO_Y*20));
    auto down = MoveBy::create(0.5f, Vec2(SCALE_RATIO_X*0, SCALE_RATIO_Y*-20));
    auto seq = RepeatForever::create(Sequence::create(up, down, nullptr));

    hand->runAction(seq);
}
