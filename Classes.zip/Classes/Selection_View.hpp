//
//  Selection_View.hpp
//  demo
//
//  Created by Pritesh on 05/01/26.
//

#ifndef Selection_View_hpp
#define Selection_View_hpp

#include <stdio.h>

#include "cocos2d.h"

using namespace cocos2d;

class Selection_View : public cocos2d::Scene
{
public:
    
    static cocos2d::Scene* createScene();

    int t;
    
    virtual bool init();
    
    CREATE_FUNC(Selection_View);
    
    Sprite *M_bg, *black_M_bg, *select_box[6],*select_border[6];
    Sprite *hand_select[6];
    Sprite *nextBtn,*prevBtn;
    void Setup_View();
    int nextprevcnt;
    
    virtual bool onTouchBegan(cocos2d::Touch*, cocos2d::Event*);
    virtual void onTouchEnded(cocos2d::Touch*, cocos2d::Event*);
    virtual void onTouchMoved(cocos2d::Touch*, cocos2d::Event*);


};
#endif /* Selection_View_hpp */
