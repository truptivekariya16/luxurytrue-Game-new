//
//  LoadingScreen.cpp
//  TruckWash
//
//  Created by IMobStudio on 6/23/16.
//
//
#include "AllHeaders.h"

USING_NS_CC;

Scene* LoadingScreen::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = LoadingScreen::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool LoadingScreen::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    percentage = 0;
    
//    background = Gen.GetSprite(this, 1, "loading_landscape.png", Point(WinSize.width/2, WinSize.height/2));

    background->runAction(Sequence::create(DelayTime::create(0.5),CallFunc::create([this](){
        if(FullAdsOnLoadingScreen){
            //BridgeIos::Show_Admob_Intertitial();
        }
        else{
            FullAdsOnLoadingScreen=true;
        }
    }), NULL));
    
    LoadingText = Sprite::create("loadingText.png");
    LoadingText->setPosition(Point(WinSize.width/2,330));
    this->addChild(LoadingText);
    
    for (int i = 0; i < 3; i++) {
        dot[i] = Sprite::create("Loadinddot.png");
        dot[i]->runAction(Hide::create());
        this->addChild(dot[i]);
    }
    dot[0]->setPosition(Point(680,300));
    dot[1]->setPosition(Point(700,300));
    dot[2]->setPosition(Point(720,300));
    
    dot[0]->runAction(RepeatForever::create(Sequence::create(DelayTime::create(0.5),Show::create(),DelayTime::create(1.0),Hide::create(), NULL)));
    dot[1]->runAction(RepeatForever::create(Sequence::create(DelayTime::create(0.8),Show::create(),DelayTime::create(0.7),Hide::create(), NULL)));
    dot[2]->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1.0),Show::create(),DelayTime::create(0.5),Hide::create(), NULL)));
    
//    per = Label::createWithTTF(__String::createWithFormat("%d  %%",percentage)->getCString(), "fonts/arial.ttf", 35);
//    per->setPosition(Point(SCALE_RATIO_X*4900,SCALE_RATIO_Y*5400));
//    per->setScale((SCALE_RATIO_X+SCALE_RATIO_Y)/2);
//    this->addChild(per);
    
    progress_panel = Sprite::create("Loadindbar_1.png");
    progress_panel->setPosition(Point(512,470));
    this->addChild(progress_panel);
    
    progress = ProgressTimer::create(Sprite::create("Loadindbar_2.png"));
    progress->setType(ProgressTimer::Type::BAR);
    progress->setMidpoint(Vec2(0.0, 0.0));
    progress->setBarChangeRate(Vec2(1, 0));
    progress->setPercentage(0);
    progress->setPosition(Point(512,470));
    this->addChild(progress);
    
    
    schedule(schedule_selector(LoadingScreen::loadingProcess),0.1);
    
    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    
    listener->onTouchBegan = CC_CALLBACK_2(LoadingScreen::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(LoadingScreen::onTouchMoved,this);
    listener->onTouchEnded = CC_CALLBACK_2(LoadingScreen::onTouchEnded,this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
    
    return true;
}

bool LoadingScreen::onTouchBegan(cocos2d::Touch *touches ,cocos2d::Event *event)
{
    return true;
}
void LoadingScreen::onTouchMoved(Touch *touches ,cocos2d::Event *event)
{
   // dot[0]->setPosition(touches->getLocation());
    CCLOG("%3.0f %3.0f",touches->getLocation().x,touches->getLocation().y);
    //Point point = truck->convertToNodeSpace(touches->getLocation());
}
void LoadingScreen::onTouchEnded(cocos2d::Touch *touches ,cocos2d::Event *event)
{
    
}
void LoadingScreen::loadingProcess(float d)
{
    if (progress->getPercentage() == 100)
    {
        progress->setPercentage(100);
        unschedule(schedule_selector(LoadingScreen::loadingProcess));
        scheduleOnce(schedule_selector(LoadingScreen::replaceScreen), 0.0);
    }
    else
    {
        progress->setPercentage(progress->getPercentage()+1);
        percentage = progress->getPercentage();
//        per->setString(__String::createWithFormat("%d %%",percentage)->getCString());
    }
}
void LoadingScreen::replaceScreen(float)
{
    if (WhichLevel == 0)
    {
        //Director::getInstance()->replaceScene(TransitionFade::create(1.0, LevelScreen::createScene()));
    }
}
