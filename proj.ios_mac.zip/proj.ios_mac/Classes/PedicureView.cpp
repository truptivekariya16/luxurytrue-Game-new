//
//  PedicureView.cpp
//  demo
//
//  Created by Pritesh on 30/01/26.
//


#include "AllHeaders.h"

Scene* PedicureView::createScene()
{
    return ManicureView::create();
}

bool PedicureView::init()
{
    if (!Scene::init())
        return false;
    
    isPopupFlag = false;
    ShowerSoundFlag = 0;
    TowelSoundFlag = 0;
    SteamSoundFlag = 0;

    t = 8;
    visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();

    outPosition = Vec2(2000*SCALE_RATIO_X,-2000*SCALE_RATIO_Y);
    
    
    //MARK: Extra view
        
        
        M_bg = Sprite::create("M_bg.png");
        M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
        M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
        this->addChild(M_bg);
        
        leg = Sprite::create(__String::createWithFormat("M2_%d.png",handNo)->getCString());
        //leg = Sprite::create("pedicure.png");
        leg->setPosition(Vec2(384*SCALE_RATIO_X,512*SCALE_RATIO_Y));
        leg->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(leg);
    
    
    particle_Shower = ParticleSystemQuad::create("waterShowerHead_SD.plist");
    particle_Shower->setLocalZOrder(100);
    particle_Shower->setVisible(false);
    this->addChild(particle_Shower);
    
    particle_Steam = ParticleSystemQuad::create("waterShowerHead_SD.plist");
    particle_Steam->setVisible(false);
    this->addChild(particle_Steam);
    
    btn_home = Sprite::create("level_next.png");
    btn_home->setPosition(Vec2(710*SCALE_RATIO_X,960*SCALE_RATIO_Y));
    btn_home->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(btn_home);
    
    home_button = Sprite::create("level.png");
    home_button->setScaleX(SCALE_RATIO_X);
    home_button->setScaleY(SCALE_RATIO_Y);
    home_button->setPosition(Point(SCALE_RATIO_X*70,SCALE_RATIO_Y*960));
    this->addChild(home_button);
    
    if (MUSIC == true)
        sound_button = Sprite::create("level_sound_btn.png");
    else
        sound_button = Sprite::create("level_mute_btn.png");
    
    sound_button->setScaleX(SCALE_RATIO_X);
    sound_button->setScaleY(SCALE_RATIO_Y);
    sound_button->setPosition(Point(SCALE_RATIO_X*70,SCALE_RATIO_Y*960));
    this->addChild(sound_button);

    setting_button = Sprite::create("level_setting_btn.png");
    setting_button->setScaleX(SCALE_RATIO_X);
    setting_button->setScaleY(SCALE_RATIO_Y);
    setting_button->setPosition(Point(SCALE_RATIO_X*70,SCALE_RATIO_Y*960));
    this->addChild(setting_button);

    Setup_View();
   // Setup_Panel();
   // setCoinPanel();

    black_M_bg = Sprite::create("blackbg.png");
    black_M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    black_M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(black_M_bg);
    black_M_bg->setVisible(false);

    PedicureView::openPopupView();

    moveDot = Sprite::create("CloseNormal.png");
    moveDot->setPosition(Vec2(SCALE_RATIO_X*12000,SCALE_RATIO_Y*152000));
    moveDot->setScale(SCALE_RATIO_X*0.6, SCALE_RATIO_Y*0.6);
    this->addChild(moveDot,-15);

    for (int i = 1; i <= 3; i++)
        soapDone[i] = false;
        currentSoapHint = -1;

    for (int i = 1; i <= 3; i++)
        pimpleDone[i] = false;
    currentPimpleHint = -1;
    
  //  PedicureView::resethintvalue(0);
    
    handHint = Sprite::create("Indication.png");
    handHint->setScale(SCALE_RATIO_X, SCALE_RATIO_Y);
    handHint->setVisible(false);
    this->addChild(handHint, 100);
    
    auto touchListener = EventListenerTouchOneByOne::create();
    
    touchListener->onTouchBegan = CC_CALLBACK_2(PedicureView::onTouchBegan, this);
    touchListener->onTouchEnded = CC_CALLBACK_2(PedicureView::onTouchEnded, this);
    touchListener->onTouchMoved = CC_CALLBACK_2(PedicureView::onTouchMoved, this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
        
    return true;
}
void PedicureView::Setup_View()
{
    
    legFullDust = Sprite::create("legdust_4.png");
    legFullDust->setScale(SCALE_RATIO_X, SCALE_RATIO_Y);
    this->addChild(legFullDust);
    legFullDust->setPosition(Vec2(380,592));
    
    for (int i = 1; i <= 5; i++) {
        Dust_Nail[i] = Sprite::create(__String::createWithFormat("nail dirt.png")->getCString());
        this->addChild(Dust_Nail[i]);
        if (i == 1)
            Dust_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        else if (i == 2)
            Dust_Nail[i]->setScale(SCALE_RATIO_X*0.8,SCALE_RATIO_Y*0.8);
        else if (i == 3)
            Dust_Nail[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
        else if (i == 4)
            Dust_Nail[i]->setScale(SCALE_RATIO_X*0.6,SCALE_RATIO_Y*0.6);
        else if (i == 5)
            Dust_Nail[i]->setScale(SCALE_RATIO_X*0.4,SCALE_RATIO_Y*0.4);
        
        Brok_Nail[i] = Sprite::create("legbrocken nail.png");
       // Brok_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(Brok_Nail[i]);
        
        if (i == 1)
            Brok_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        else if (i == 2)
            Brok_Nail[i]->setScale(SCALE_RATIO_X*0.8,SCALE_RATIO_Y*0.8);
        else if (i == 3)
            Brok_Nail[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
        else if (i == 4)
            Brok_Nail[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
        else if (i == 5)
            Brok_Nail[i]->setScale(SCALE_RATIO_X*0.4,SCALE_RATIO_Y*0.4);
    }
    
    Dust_Nail[1]->setPosition(Vec2(231,1116));
    Dust_Nail[2]->setPosition(Vec2(326,1134));
    Dust_Nail[3]->setPosition(Vec2(409,1110));
    Dust_Nail[4]->setPosition(Vec2(481,1038));
    Dust_Nail[5]->setPosition(Vec2(549,967));
    
    Brok_Nail[1]->setPosition(Vec2(228,1158));
    Brok_Nail[2]->setPosition(Vec2(324,1163));
    Brok_Nail[3]->setPosition(Vec2(409,1138));
    Brok_Nail[4]->setPosition(Vec2(484,1065));
    Brok_Nail[5]->setPosition(Vec2(547,982));
    
    //set Pimple
    {
        for (int i = 1; i <= 3; i++) {
            pimple[i] = Sprite::create("pimple1_1.png");
            this->addChild(pimple[i]);
            if (i == 1)
                pimple[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
            else if (i == 2)
                pimple[i]->setScale(SCALE_RATIO_X*0.6,SCALE_RATIO_Y*0.6);
            else if (i == 3)
                pimple[i]->setScale(SCALE_RATIO_X*0.4,SCALE_RATIO_Y*0.4);
        }
        
        pimple[1]->setPosition(Vec2(463,607));
        pimple[2]->setPosition(Vec2(324,502));
        pimple[3]->setPosition(Vec2(250,776));
        pimple[4] = Sprite::create("pimple5.png");
        this->addChild(pimple[4]);
        pimple[4]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
        pimple[4]->setPosition(Vec2(341,386));
        
        for (int i = 5; i <= 7; i++) {
            pimple[i] = Sprite::create("pimple4.png");
            this->addChild(pimple[i]);
            if (i == 5 || i == 6)
            pimple[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            else
                pimple[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7 );
            
        }
        pimple[5]->setPosition(Vec2(544,686));
        pimple[6]->setPosition(Vec2(526,488));
        pimple[7]->setPosition(Vec2(490,822));
        
        pimple[8] = Sprite::create("pimple2.png");
        this->addChild(pimple[8]);
        pimple[8]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
        pimple[8]->setFlippedX(true);
        pimple[8]->setPosition(Vec2(501,832));
    }
    
    for (int i = 1; i <= 3; i++) {
        legDust[i] = Sprite::create(__String::createWithFormat("dust_%d.png",i)->getCString());
        legDust[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(legDust[i]);
        
        legDotDust[i] = Sprite::create(__String::createWithFormat("dustdot_%d.png",i)->getCString());
        legDotDust[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(legDotDust[i]);
        
    }
    legDust[1]->setPosition(Vec2(310,386));
    legDust[2]->setPosition(Vec2(522,535));
    legDust[3]->setPosition(Vec2(378,749));
    
    legDotDust[1]->setPosition(Vec2(303,773));
    legDotDust[2]->setPosition(Vec2(502,470));
    legDotDust[3]->setPosition(Vec2(344,373));
    
    for (int i = 1; i <= 3; i++) {
        pinksoap[i] = Sprite::create("pinksoap.png");
        pinksoap[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(pinksoap[i]);
        pinksoap[i]->setOpacity(255);
        
        pinksoapdummy[i] = Sprite::create("pinksoap.png");
        pinksoapdummy[i]->setScale(SCALE_RATIO_X*0.3,SCALE_RATIO_Y*0.3);
        this->addChild(pinksoapdummy[i]);
        pinksoapdummy[i]->setOpacity(0);

    }
    

}
void PedicureView::openPopupView()
{
    
}
bool PedicureView::onTouchBegan(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());

    return true;
}
void PedicureView::onTouchMoved(Touch* touch, Event* event)
{
    Vec2 location = this->convertToNodeSpace(touch->getLocation());
    pimple[t]->setPosition(location);
}
void PedicureView::onTouchEnded(Touch* touch, Event* event)
{
    Vec2 location = this->convertToNodeSpace(touch->getLocation());
    log("pimple[%d]->setPosition(Vec2(%0.0f,%0.0f));",t, location.x, location.y);
    t++;
}
