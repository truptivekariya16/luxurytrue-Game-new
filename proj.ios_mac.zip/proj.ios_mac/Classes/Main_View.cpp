//
//  Main_View.cpp
//  demo
//
//  Created by Pritesh on 20/01/26.
//

#include "AllHeaders.h"

USING_NS_CC;

Scene* Main_View::createScene()
{
    return Main_View::create();
}

bool Main_View::init()
{
    if (!Scene::init())
    {
        return false;
    }
    M_bg = Sprite::create("mainbg.png");
    M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(M_bg);
    
    ParticleSystemQuad *bgParticle = ParticleSystemQuad::create("bg_light.plist");
    bgParticle->setPosition(Vec2(384, 1124));
    this->addChild(bgParticle);
    
    Setup_View();
    
    auto touchListener = EventListenerTouchOneByOne::create();
    
    touchListener->onTouchBegan = CC_CALLBACK_2(Main_View::onTouchBegan, this);
    touchListener->onTouchEnded = CC_CALLBACK_2(Main_View::onTouchEnded, this);
    touchListener->onTouchMoved = CC_CALLBACK_2(Main_View::onTouchMoved, this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
    
    return true;
}
void Main_View::Setup_View()
{
    btn_play = Sprite::create("play.png");
    btn_play->setPosition(Vec2(465*SCALE_RATIO_X,498*SCALE_RATIO_Y));
    btn_play->setScale(SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0);
    this->addChild(btn_play);
    btn_play->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1.0),ScaleTo::create(0.15, 0.4,1),ScaleTo::create(0.15, 1,0.4),ScaleTo::create(0.15, 1), NULL)));
    
    
    img_Girl = Sprite::create("main_girl.png");
    img_Girl->setPosition(Vec2(217*SCALE_RATIO_X,345*SCALE_RATIO_Y));
    img_Girl->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(img_Girl);
    
    hand = Sprite::create("main_hand.png");
    hand->setPosition(Vec2(188*SCALE_RATIO_X,376*SCALE_RATIO_Y));
    hand->setAnchorPoint(Vec2(0.1, 0.1));
    hand->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(hand);
    hand->runAction(RepeatForever::create(Sequence::create(RotateTo::create(0.5, -20),RotateTo::create(0.5, 0),DelayTime::create(2.0),RotateTo::create(0.5, 20),RotateTo::create(0.4, 0),DelayTime::create(4.0), NULL)));
    
    face = Sprite::create("main_face.png");
    face->setPosition(Vec2(116*SCALE_RATIO_X,508*SCALE_RATIO_Y));
    face->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(face);
    face->runAction(RepeatForever::create(Sequence::create(RotateTo::create(0.5, -3),RotateTo::create(0.5, 0),DelayTime::create(3.0),RotateTo::create(0.8, 3),RotateTo::create(0.5, 0),DelayTime::create(2.0), NULL)));
    
    eye = Sprite::create("main_eyes.png");
    eye->setPosition(Vec2(80,186));
    face->addChild(eye);

    eye->runAction(RepeatForever::create(Sequence::create(Blink::create(1.5, 1),Hide::create(),DelayTime::create(2.2),Show::create(), NULL)));
    
    img_3 = Sprite::create("main_chair.png");
    img_3->setPosition(Vec2(358*SCALE_RATIO_X,333*SCALE_RATIO_Y));
    img_3->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(img_3);
    
    
}
bool Main_View::onTouchBegan(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    if(btn_play->getBoundingBox().containsPoint(location) && btn_play->getOpacity() == 255){
        btn_play->setOpacity(254);
        if(MUSIC == true){
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Play_Btn.mp3");
        }
        btn_play->runAction(Sequence::create(ScaleTo::create(0.2, 0.8),ScaleTo::create(0.2, 1.0),CallFunc::create([this]{
            //Director::getInstance()->replaceScene(Selection_View::create());
            Director::getInstance()->replaceScene(TransitionCrossFade::create(0.5f, Selection_View::create()));
        }), NULL));
        
        
    }
    return true;
}
void Main_View::onTouchMoved(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    //select_border[1]->setPosition(location);
    //eye->setPosition(location);
}
void Main_View::onTouchEnded(Touch* touch, Event* event)
{
    
    Point location = this->convertToNodeSpace(touch->getLocation());
  //  log("select_border[1]->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",location.x,location.y);
    
    log("img_3->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",location.x,location.y);

   // t++;
}
