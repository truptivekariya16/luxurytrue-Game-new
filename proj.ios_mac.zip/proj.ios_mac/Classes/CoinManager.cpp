//
//  CoinManager.cpp
//  demo
//
//  Created by Pritesh on 10/01/26.
//

#include "AllHeaders.h"

static int g_coins = 100;   // initial coins

int CoinManager::getCoins()
{
    return g_coins;
}

void CoinManager::addCoins(int value)
{
    g_coins += value;
}

void CoinManager::spendCoins(int value)
{
    g_coins -= value;
    if (g_coins < 0) g_coins = 0;
}
