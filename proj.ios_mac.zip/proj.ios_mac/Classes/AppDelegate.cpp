#include "AllHeaders.h"
int WhichLevel;
bool NetwokCheck = false;
int SNAP = 1;
int BtnPosI5;
int ToolPosI5;

cocos2d::Size WinSize;
bool iPhone5;
bool FullAdsOnLoadingScreen;


int MUSIC = true;
int ishand = 1;
int handNo = 1;

USING_NS_CC;

static cocos2d::Size designResolutionSize = cocos2d::Size(480, 320);
static cocos2d::Size smallResolutionSize = cocos2d::Size(480, 320);
static cocos2d::Size mediumResolutionSize = cocos2d::Size(1024, 768);
static cocos2d::Size largeResolutionSize = cocos2d::Size(2048, 1536);

AppDelegate::AppDelegate()
{
}

AppDelegate::~AppDelegate() 
{
}

// if you want a different context, modify the value of glContextAttrs
// it will affect all platforms
void AppDelegate::initGLContextAttrs()
{
    // set OpenGL context attributes: red,green,blue,alpha,depth,stencil
    GLContextAttrs glContextAttrs = {8, 8, 8, 8, 24, 8};

    GLView::setGLContextAttrs(glContextAttrs);
}

// if you want to use the package manager to install more packages,  
// don't modify or remove this function
static int register_all_packages()
{
    return 0; //flag for packages manager
}

bool AppDelegate::applicationDidFinishLaunching() {
    // initialize director
    auto director = Director::getInstance();
    auto glview = director->getOpenGLView();
    if(!glview) {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32) || (CC_TARGET_PLATFORM == CC_PLATFORM_MAC) || (CC_TARGET_PLATFORM == CC_PLATFORM_LINUX)
        glview = GLViewImpl::createWithRect("MyGame", cocos2d::Rect(0, 0, designResolutionSize.width, designResolutionSize.height));
#else
        glview = GLViewImpl::create("MyGame");
#endif
        director->setOpenGLView(glview);
    }

    // turn on display FPS
    director->setDisplayStats(false);

    // set FPS. the default value is 1.0/60 if you don't call this
    director->setAnimationInterval(1.0f / 60);
/*
    // Set the design resolution
    glview->setDesignResolutionSize(designResolutionSize.width, designResolutionSize.height, ResolutionPolicy::NO_BORDER);
    auto frameSize = glview->getFrameSize();
    // if the frame's height is larger than the height of medium size.
    if (frameSize.height > mediumResolutionSize.height)
    {        
        director->setContentScaleFactor(MIN(largeResolutionSize.height/designResolutionSize.height, largeResolutionSize.width/designResolutionSize.width));
    }
    // if the frame's height is larger than the height of small size.
    else if (frameSize.height > smallResolutionSize.height)
    {        
        director->setContentScaleFactor(MIN(mediumResolutionSize.height/designResolutionSize.height, mediumResolutionSize.width/designResolutionSize.width));
    }
    // if the frame's height is smaller than the height of medium size.
    else
    {        
        director->setContentScaleFactor(MIN(smallResolutionSize.height/designResolutionSize.height, smallResolutionSize.width/designResolutionSize.width));
    }
*/
    
    /*—————————————————————IPHONE CONDITION START————————————————————————————*/
    WinSize =  Director::getInstance()->getVisibleSize();
    
    if (WinSize.width>WinSize.height)//LANDSCAPE
    {
        if((WinSize.width==960 && WinSize.height==640) /*iPhone 4*/||
           (WinSize.width==1136 && WinSize.height==640)/*iPhone5s, iPhone 6, iPhone 6s, iPhone 7*/ ||
           (WinSize.width==1334 && WinSize.height==750)/*Retina HD 4.7 (iPhone 6)*/||
           (WinSize.width==2208 && WinSize.height==1242)/*Retina HD 5.5 (iPhone 6, 7, 8 Plus)*/ ||
           (WinSize.width==1920 && WinSize.height==1242)/*Retina HD 5.5 (iPhone 6, 7, 8 Plus)*/ ||
           (WinSize.width==1704 && WinSize.height==960)/*iPhone 6 Plus, iPhone 7 Plus*/ ||
           /*(WinSize.width==2048 && WinSize.height==1536) iPad Pro (9.7 inch) ||*/
           /*(WinSize.width==2732 && WinSize.height==2048) iPad Pro (12.9 inch) ||*/
           (WinSize.width==2436 && WinSize.height==1125)/* iPhone X*/)
        {
            iPhone5=true;
        }
    }
    else//PORTRAIT
    {

        if((WinSize.width==640 && WinSize.height==960) /*iPhone 4*/||
           (WinSize.width==640 && WinSize.height==1136)/*iPhone5s, iPhone 6, iPhone 6s, iPhone 7*/ ||
           (WinSize.width==750 && WinSize.height==1334)/*Retina HD 4.7 (iPhone 6)*/||
           (WinSize.width==1242 && WinSize.height==2208)/*Retina HD 5.5 (iPhone 6, 7, 8 Plus)*/ ||
           (WinSize.width==1242 && WinSize.height==1920)/*Retina HD 5.5 (iPhone 6, 7, 8 Plus)*/ ||
           (WinSize.width==960 && WinSize.height==1704)/*iPhone 6 Plus, iPhone 7 Plus*/ ||
           /*(WinSize.width==1536 && WinSize.height==2048) iPad Pro (9.7 inch) ||*/
           /*(WinSize.width==2048 && WinSize.height==2732) iPad Pro (12.9 inch) ||*/
           (WinSize.width==1125 && WinSize.height==2436)/* iPhone X*/)
        {
            iPhone5=true;
        }
    }
    /*————————————————————————IPHONE CONDITION END——————————————————————————*/
    
    
    SoundMacro->playBackgroundMusic("FarmerGarden_BgMusic.mp3",true);
    SoundMacro->setBackgroundMusicVolume(0.6);

    register_all_packages();

#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
    iPhone5=true;
    if (WinSize.width>WinSize.height)
    {
        glview->setDesignResolutionSize(1024, 768, ResolutionPolicy::EXACT_FIT);
    }else{
        glview->setDesignResolutionSize(768, 1024, ResolutionPolicy::EXACT_FIT);
    }
#endif

    // create a scene. it's an autorelease object
    auto scene = Main_View::createScene();

    // run
    director->runWithScene(scene);

    return true;
}

// This function will be called when the app is inactive. Note, when receiving a phone call it is invoked.
void AppDelegate::applicationDidEnterBackground() {
    Director::getInstance()->stopAnimation();

    // if you use SimpleAudioEngine, it must be paused
    // SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground() {
    Director::getInstance()->startAnimation();

    // if you use SimpleAudioEngine, it must resume here
    // SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
}
