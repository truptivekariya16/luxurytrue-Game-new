//
//  LoadingScreen.h
//  TruckWash
//
//  Created by IMobStudio on 6/23/16.
//
//

#ifndef __TruckWash__LoadingScreen__
#define __TruckWash__LoadingScreen__

#include <stdio.h>

using namespace cocos2d;
class LoadingScreen : public cocos2d::Layer
{
public:
    
    int t;
    
    bool onTouchBegan(cocos2d::Touch *touches ,cocos2d::Event *event);
    virtual void onTouchMoved(cocos2d::Touch *touches ,cocos2d::Event *event);
    virtual void onTouchEnded(cocos2d::Touch *touches ,cocos2d::Event *event);
    
    
    Sprite *background;
    Sprite *LoadingText;
    Sprite *dot[3];
    Sprite *progress_panel;
    ProgressTimer *progress;
    int percentage;
    Label *per;
    
    void replaceScreen(float d);
    
    void loadingProcess(float d);
    static cocos2d::Scene* createScene();
    virtual bool init();
    // implement the "static create()" method manually
    CREATE_FUNC(LoadingScreen);
};
#endif /* defined(__TruckWash__LoadingScreen__) */
