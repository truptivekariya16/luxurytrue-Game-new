//
//  AllHeaders.hpp
//  Makeover
//
//  Created by Sanjay Rudani on 12/19/17.
//
//

#ifndef AllHeaders_hpp
#define AllHeaders_hpp

#include <stdio.h>
#include "AllHeaders.h"
#include "AppDelegate.h"
#include "SimpleAudioEngine.h"
#include "HelloWorldScene.h"
#include "LoadingScreen.h"
#include "Macro.h"
#include "Main_View.hpp"
#include "Selection_View.hpp"
#include "ManicureView.hpp"
#include "PedicureView.hpp"
#include "CoinManager.hpp"


#define TapEffect Sequence::create(ScaleTo::create(0.2, 0.8),ScaleTo::create(0.2, 1.0), NULL)
#define MoreAppEffect Sequence::create(ScaleTo::create(0.15, 0.4,1),ScaleTo::create(0.15, 1,0.4),ScaleTo::create(0.15, 1), DelayTime::create(1), NULL)

#define ToolEndDuration 0.5
#define UIButtonSound SoundMacro->playEffect("Other button.mp3");
#define ToolTapSound SoundMacro->playEffect("Tap Button.mp3");
#define SoundMacro CocosDenshion::SimpleAudioEngine::getInstance()
#define EntrySFX SoundMacro->playEffect("entry_sfx.mp3");
#define ExitSFX SoundMacro->playEffect("exit_sfx.mp3");
#define PopupOpenSFX SoundMacro->playEffect("popupopen.mp3");
#define PopupCloseSFX SoundMacro->playEffect("popupclose.mp3");
#define OUTOFSCREEN Vec2(100000, 100000)
#define ReplaceScene Director::getInstance()

#define PhaseCompletionParticle {this->runAction(Sequence::create(DelayTime::create(1), CallFunc::create([this](){SoundMacro->stopEffect(SoundID);switch (random(1, 4)){case 1:SoundMacro->playEffect("vac_snd_8.mp3");break;case 2:SoundMacro->playEffect("vac_snd_10.mp3");break;case 3:SoundMacro->playEffect("vac_snd_9.mp3");break;case 4:SoundMacro->playEffect("vac_snd_5.mp3");break;}SoundMacro->playEffect("done.mp3");ParticleSystemQuad *completeParticle = ParticleSystemQuad::create("PhaseCompleteParticle.plist"); completeParticle->setPosition(Vec2(WinSize.width/2,WinSize.height/2)); completeParticle->setScale(1); this->addChild(completeParticle,50);}), NULL));}

#define EatViewCompletionParticle {this->runAction(Sequence::create(DelayTime::create(0.5), CallFunc::create([this](){SoundMacro->playEffect("vac_snd_8.mp3");SoundMacro->playEffect("Level Complete particle.mp3");ParticleSystemQuad *completeParticle1 = ParticleSystemQuad::create("FC_EatViewCompletionParticle.plist"); completeParticle1->setPosition(Vec2(512, 384));this->addChild(completeParticle1,500);ParticleSystemQuad *completeParticle2 = ParticleSystemQuad::create("FC_EatViewCompletionParticle1.plist"); completeParticle2->setPosition(Vec2(512, 384));this->addChild(completeParticle2,500);ParticleSystemQuad *completeParticle3 = ParticleSystemQuad::create("FC_EatViewCompletionParticle2.plist"); completeParticle3->setPosition(Vec2(512, 384)); this->addChild(completeParticle3,500);}), NULL));}

using namespace CocosDenshion;

#endif /* AllHeaders_hpp */
