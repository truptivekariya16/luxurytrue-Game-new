//
//  ManicureView.cpp
//  demo
//
//  Created by Pritesh on 05/01/26.
//

#include "AllHeaders.h"
Scene* ManicureView::createScene()
{
    return ManicureView::create();
}

bool ManicureView::init()
{
    if (!Scene::init())
        return false;
    
    isPopupFlag = false;
    ShowerSoundFlag = 0;
    TowelSoundFlag = 0;
    SteamSoundFlag = 0;

    t = 1;
    visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();

    outPosition = Vec2(2000*SCALE_RATIO_X,-2000*SCALE_RATIO_Y);
    
//MARK: Extra view
    
    
    M_bg = Sprite::create("M_bg.png");
    M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(M_bg);
    
    hand = Sprite::create(__String::createWithFormat("M1_%d.png",handNo)->getCString());
    hand->setPosition(Vec2(384*SCALE_RATIO_X,512*SCALE_RATIO_Y));
    hand->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
    this->addChild(hand);
    
    particle_Shower = ParticleSystemQuad::create("waterShowerHead_SD.plist");
    particle_Shower->setLocalZOrder(100);
    particle_Shower->setVisible(false);
    this->addChild(particle_Shower);
    
    particle_Steam = ParticleSystemQuad::create("waterShowerHead_SD.plist");
    particle_Steam->setVisible(false);
    this->addChild(particle_Steam);
    
    btn_home = Sprite::create("level_next.png");
    btn_home->setPosition(Vec2(710*SCALE_RATIO_X,960*SCALE_RATIO_Y));
    btn_home->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(btn_home);
    
    home_button = Sprite::create("level.png");
    home_button->setScaleX(SCALE_RATIO_X);
    home_button->setScaleY(SCALE_RATIO_Y);
    home_button->setPosition(Point(SCALE_RATIO_X*70,SCALE_RATIO_Y*960));
    this->addChild(home_button);

    if (MUSIC == true)
        sound_button = Sprite::create("level_sound_btn.png");
    else
        sound_button = Sprite::create("level_mute_btn.png");
    
    sound_button->setScaleX(SCALE_RATIO_X);
    sound_button->setScaleY(SCALE_RATIO_Y);
    sound_button->setPosition(Point(SCALE_RATIO_X*70,SCALE_RATIO_Y*960));
    this->addChild(sound_button);

    setting_button = Sprite::create("level_setting_btn.png");
    setting_button->setScaleX(SCALE_RATIO_X);
    setting_button->setScaleY(SCALE_RATIO_Y);
    setting_button->setPosition(Point(SCALE_RATIO_X*70,SCALE_RATIO_Y*960));
    this->addChild(setting_button);

    
    Setup_View();
    Setup_Panel();
    setCoinPanel();

    black_M_bg = Sprite::create("blackbg.png");
    black_M_bg->setPosition(Vec2(IPAD_WIDTH/2, IPAD_HEIGHT/2));
    black_M_bg->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(black_M_bg);
    black_M_bg->setVisible(false);

    ManicureView::openPopupView();

    moveDot = Sprite::create("CloseNormal.png");
    moveDot->setPosition(Vec2(SCALE_RATIO_X*12000,SCALE_RATIO_Y*152000));
    moveDot->setScale(SCALE_RATIO_X*0.6, SCALE_RATIO_Y*0.6);
    this->addChild(moveDot,-15);

    for (int i = 1; i <= 3; i++)
        soapDone[i] = false;
        currentSoapHint = -1;

    for (int i = 1; i <= 3; i++)
        pimpleDone[i] = false;
    currentPimpleHint = -1;
    
    ManicureView::resethintvalue(0);

    handHint = Sprite::create("Indication.png");
    handHint->setScale(SCALE_RATIO_X, SCALE_RATIO_Y);
    handHint->setVisible(false);
    this->addChild(handHint, 100);

    
    
    auto touchListener = EventListenerTouchOneByOne::create();
    
    touchListener->onTouchBegan = CC_CALLBACK_2(ManicureView::onTouchBegan, this);
    touchListener->onTouchEnded = CC_CALLBACK_2(ManicureView::onTouchEnded, this);
    touchListener->onTouchMoved = CC_CALLBACK_2(ManicureView::onTouchMoved, this);
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
    
    return true;
}
void ManicureView::Setup_View()
{
    handFullDust = Sprite::create("dust_4.png");
    handFullDust->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
    this->addChild(handFullDust);
    handFullDust->setPosition(Vec2(391*SCALE_RATIO_X,500*SCALE_RATIO_Y));
    
    
    for (int i = 1; i <= 3; i++) {
        handDust[i] = Sprite::create(__String::createWithFormat("dust_%d.png",i)->getCString());
        handDust[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(handDust[i]);
        
        handDotDust[i] = Sprite::create(__String::createWithFormat("dustdot_%d.png",i)->getCString());
        handDotDust[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(handDotDust[i]);
        
        
    }
    handDust[1]->setPosition(Vec2(295*SCALE_RATIO_X,295*SCALE_RATIO_Y));
    handDust[2]->setPosition(Vec2(472*SCALE_RATIO_X,257*SCALE_RATIO_Y));
    handDust[3]->setPosition(Vec2(369*SCALE_RATIO_X,441*SCALE_RATIO_Y));

    handDotDust[1]->setPosition(Vec2(327*SCALE_RATIO_X,440*SCALE_RATIO_Y));
    handDotDust[2]->setPosition(Vec2(455*SCALE_RATIO_X,240*SCALE_RATIO_Y));
    handDotDust[3]->setPosition(Vec2(309*SCALE_RATIO_X,243*SCALE_RATIO_Y));

    for (int i = 1; i <= 5; i++) {
        Dust_Nail[i] = Sprite::create(__String::createWithFormat("nail_dust_%d.png",i)->getCString());
        Dust_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(Dust_Nail[i]);
        
        Brok_Nail[i] = Sprite::create("brocken nails.png");
        Brok_Nail[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(Brok_Nail[i]);
    }
   
    Dust_Nail[1]->setPosition(Vec2(650*SCALE_RATIO_X,543*SCALE_RATIO_Y));
    Dust_Nail[2]->setPosition(Vec2(488*SCALE_RATIO_X,823*SCALE_RATIO_Y));
    Dust_Nail[3]->setPosition(Vec2(366*SCALE_RATIO_X,868*SCALE_RATIO_Y));
    Dust_Nail[4]->setPosition(Vec2(252*SCALE_RATIO_X,818*SCALE_RATIO_Y));
    Dust_Nail[5]->setPosition(Vec2(142*SCALE_RATIO_X,696*SCALE_RATIO_Y));

    Brok_Nail[1]->setPosition(Vec2(652*SCALE_RATIO_X,562*SCALE_RATIO_Y));
    Brok_Nail[2]->setPosition(Vec2(488*SCALE_RATIO_X,848*SCALE_RATIO_Y));
    Brok_Nail[3]->setPosition(Vec2(367*SCALE_RATIO_X,901*SCALE_RATIO_Y));
    Brok_Nail[4]->setPosition(Vec2(252*SCALE_RATIO_X,845*SCALE_RATIO_Y));
    Brok_Nail[5]->setPosition(Vec2(142*SCALE_RATIO_X,715*SCALE_RATIO_Y));

    //set Pimple
    {
        for (int i = 1; i <= 3; i++) {
            pimple[i] = Sprite::create("pimple1_1.png");
            this->addChild(pimple[i]);
            if (i == 1)
                pimple[i]->setScale(SCALE_RATIO_X*0.8,SCALE_RATIO_Y*0.8);
            else if (i == 2)
                pimple[i]->setScale(SCALE_RATIO_X*0.6,SCALE_RATIO_Y*0.6);
            else if (i == 3)
                pimple[i]->setScale(SCALE_RATIO_X*0.4,SCALE_RATIO_Y*0.4);
        }
        
        for (int i = 4; i <= 5; i++) {
            pimple[i] = Sprite::create("pimple5.png");
            this->addChild(pimple[i]);
            if (i == 4)
                pimple[i]->setScale(SCALE_RATIO_X*0.7,SCALE_RATIO_Y*0.7);
            else if (i == 5)
                pimple[i]->setScale(SCALE_RATIO_X*0.55,SCALE_RATIO_Y*0.55);
        }
        
        for (int i = 6; i <= 7; i++) {
            pimple[i] = Sprite::create("pimple4.png");
            this->addChild(pimple[i]);
            pimple[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        }
        
        
        pimple[8] = Sprite::create("pimple2.png");
        this->addChild(pimple[8]);
        pimple[8]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
        pimple[8]->setFlippedX(true);
        pimple[8]->setPosition(Vec2(424*SCALE_RATIO_X,545*SCALE_RATIO_Y));
        
        for (int i = 1; i <= 3; i++) {
            pinksoap[i] = Sprite::create("pinksoap.png");
            pinksoap[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            this->addChild(pinksoap[i]);
            pinksoap[i]->setOpacity(0);
            
            pinksoapdummy[i] = Sprite::create("pinksoap.png");
            pinksoapdummy[i]->setScale(SCALE_RATIO_X*0.3,SCALE_RATIO_Y*0.3);
            this->addChild(pinksoapdummy[i]);
            pinksoapdummy[i]->setOpacity(0);

        }
        pimple[1]->setPosition(Vec2(453*SCALE_RATIO_X,408*SCALE_RATIO_Y));
        pimple[2]->setPosition(Vec2(280*SCALE_RATIO_X,338*SCALE_RATIO_Y));
        pimple[3]->setPosition(Vec2(221*SCALE_RATIO_X,490*SCALE_RATIO_Y));
        pimple[4]->setPosition(Vec2(286*SCALE_RATIO_X,504*SCALE_RATIO_Y));
        pimple[5]->setPosition(Vec2(298*SCALE_RATIO_X,246*SCALE_RATIO_Y));
        pimple[6]->setPosition(Vec2(487*SCALE_RATIO_X,326*SCALE_RATIO_Y));
        pimple[7]->setPosition(Vec2(450*SCALE_RATIO_X,582*SCALE_RATIO_Y));
        pimple[8]->setPosition(Vec2(459*SCALE_RATIO_X,590*SCALE_RATIO_Y));

        pinksoap[1]->setPosition(Vec2(256*SCALE_RATIO_X,281*SCALE_RATIO_Y));
        pinksoap[2]->setPosition(Vec2(332*SCALE_RATIO_X,471*SCALE_RATIO_Y));
        pinksoap[3]->setPosition(Vec2(461*SCALE_RATIO_X,288*SCALE_RATIO_Y));

        
        soapHintPos[1] = Vec2(280*SCALE_RATIO_X,277*SCALE_RATIO_Y);
        soapHintPos[2] = Vec2(356*SCALE_RATIO_X,461*SCALE_RATIO_Y);
        soapHintPos[3] = Vec2(478*SCALE_RATIO_X,280*SCALE_RATIO_Y);

        pinksoapdummy[1]->setPosition(Vec2(256*SCALE_RATIO_X,293*SCALE_RATIO_Y));
        pinksoapdummy[2]->setPosition(Vec2(335*SCALE_RATIO_X,486*SCALE_RATIO_Y));
        pinksoapdummy[3]->setPosition(Vec2(460*SCALE_RATIO_X,298*SCALE_RATIO_Y));

        
        for (int i = 1; i <= 3; i++) {
            whitecream[i] = Sprite::create("whitecream.png");
            whitecream[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
            this->addChild(whitecream[i]);
            whitecream[i]->setOpacity(0);
        }
        whitecream[1]->setPosition(Vec2(253*SCALE_RATIO_X,366*SCALE_RATIO_Y));
        whitecream[2]->setPosition(Vec2(395*SCALE_RATIO_X,473*SCALE_RATIO_Y));
        whitecream[3]->setPosition(Vec2(456*SCALE_RATIO_X,287*SCALE_RATIO_Y));

        for (int i = 1; i <= 30; i++) {
            bubble[i] = Sprite::create("pinkbubble.png");
            bubble[i]->setScale(SCALE_RATIO_X*0.8,SCALE_RATIO_Y*0.8);
            this->addChild(bubble[i]);
            bubble[i]->setOpacity(0);
        }

        bubble[1]->setPosition(Vec2(290*SCALE_RATIO_X,262*SCALE_RATIO_Y));
        bubble[2]->setPosition(Vec2(275*SCALE_RATIO_X,306*SCALE_RATIO_Y));
        bubble[3]->setPosition(Vec2(253*SCALE_RATIO_X,382*SCALE_RATIO_Y));
        bubble[4]->setPosition(Vec2(238*SCALE_RATIO_X,475*SCALE_RATIO_Y));
        bubble[5]->setPosition(Vec2(207*SCALE_RATIO_X,557*SCALE_RATIO_Y));
        bubble[6]->setPosition(Vec2(194*SCALE_RATIO_X,606*SCALE_RATIO_Y));
        bubble[7]->setPosition(Vec2(281*SCALE_RATIO_X,652*SCALE_RATIO_Y));
        bubble[8]->setPosition(Vec2(356*SCALE_RATIO_X,729*SCALE_RATIO_Y));
        bubble[9]->setPosition(Vec2(407*SCALE_RATIO_X,771*SCALE_RATIO_Y));
        bubble[10]->setPosition(Vec2(495*SCALE_RATIO_X,741*SCALE_RATIO_Y));
        bubble[11]->setPosition(Vec2(473*SCALE_RATIO_X,656*SCALE_RATIO_Y));
        bubble[12]->setPosition(Vec2(455*SCALE_RATIO_X,549*SCALE_RATIO_Y));
        bubble[13]->setPosition(Vec2(374*SCALE_RATIO_X,641*SCALE_RATIO_Y));
        bubble[14]->setPosition(Vec2(323*SCALE_RATIO_X,551*SCALE_RATIO_Y));
        bubble[15]->setPosition(Vec2(359*SCALE_RATIO_X,468*SCALE_RATIO_Y));
        bubble[16]->setPosition(Vec2(369*SCALE_RATIO_X,408*SCALE_RATIO_Y));
        bubble[17]->setPosition(Vec2(429*SCALE_RATIO_X,463*SCALE_RATIO_Y));
        bubble[18]->setPosition(Vec2(461*SCALE_RATIO_X,377*SCALE_RATIO_Y));
        bubble[19]->setPosition(Vec2(388*SCALE_RATIO_X,340*SCALE_RATIO_Y));
        bubble[20]->setPosition(Vec2(427*SCALE_RATIO_X,265*SCALE_RATIO_Y));
        bubble[21]->setPosition(Vec2(485*SCALE_RATIO_X,224*SCALE_RATIO_Y));
        bubble[22]->setPosition(Vec2(552*SCALE_RATIO_X,365*SCALE_RATIO_Y));
        bubble[23]->setPosition(Vec2(590*SCALE_RATIO_X,448*SCALE_RATIO_Y));
        bubble[24]->setPosition(Vec2(547*SCALE_RATIO_X,432*SCALE_RATIO_Y));
        bubble[25]->setPosition(Vec2(419*SCALE_RATIO_X,561*SCALE_RATIO_Y));
        bubble[26]->setPosition(Vec2(271*SCALE_RATIO_X,389*SCALE_RATIO_Y));
        bubble[27]->setPosition(Vec2(332*SCALE_RATIO_X,248*SCALE_RATIO_Y));
        bubble[28]->setPosition(Vec2(240*SCALE_RATIO_X,507*SCALE_RATIO_Y));
        bubble[29]->setPosition(Vec2(494*SCALE_RATIO_X,304*SCALE_RATIO_Y));
        bubble[30]->setPosition(Vec2(268*SCALE_RATIO_X,224*SCALE_RATIO_Y));

        for (int i = 1; i <= 30; i++) {
            bubbledummy[i] = Sprite::create("pinkbubble.png");
            bubbledummy[i]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
            this->addChild(bubbledummy[i]);
            bubbledummy[i]->setOpacity(0);
            bubbledummy[i]->setPosition(bubble[i]->getPosition());
        }
    }
}
void ManicureView::Setup_Panel()
{
    panel = Sprite::create("PENAL.png");
    panel->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
    this->addChild(panel);
    panel->setPosition(Vec2(384*SCALE_RATIO_X,50*SCALE_RATIO_Y));
    
    toolpos[1] = Vec2(147*SCALE_RATIO_X,190*SCALE_RATIO_Y);
    toolpos[2] = Vec2(392*SCALE_RATIO_X,129*SCALE_RATIO_Y);
    toolpos[3] = Vec2(615*SCALE_RATIO_X,178*SCALE_RATIO_Y);
    toolpos[4] = Vec2(165*SCALE_RATIO_X,105*SCALE_RATIO_Y);
    toolpos[5] = Vec2(425*SCALE_RATIO_X,158*SCALE_RATIO_Y);
    toolpos[6] = Vec2(650*SCALE_RATIO_X,149*SCALE_RATIO_Y);
    toolpos[7] = Vec2(206*SCALE_RATIO_X, 85*SCALE_RATIO_Y);
    toolpos[8] = Vec2(568*SCALE_RATIO_X, 73*SCALE_RATIO_Y);

    for (int i = 1; i <= 8; i++) {
        PanelTool[i] = Sprite::create(__String::createWithFormat("PanelTool%d.png",i)->getCString());
        PanelTool[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(PanelTool[i]);
        PanelTool[i]->setOpacity(254);
        PanelTool[i]->setPosition(Vec2(toolpos[i].x,SCALE_RATIO_Y*-420));

    }
    
    PanelTool[1]->runAction(Sequence::create(DelayTime::create(0.5),CallFunc::create([](){
        if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),EaseSineOut::create(MoveTo::create(0.5, toolpos[1])),nullptr));
    PanelTool[2]->runAction(Sequence::create(DelayTime::create(0.7),CallFunc::create([](){
        if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),EaseSineOut::create(MoveTo::create(0.5, toolpos[2])),nullptr));
    PanelTool[3]->runAction(Sequence::create(DelayTime::create(0.9),CallFunc::create([](){
        if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),EaseSineOut::create(MoveTo::create(0.5, toolpos[3])),CallFunc::create([this](){
        ManicureView::toolComplete(0.5);
        startSoapHint(toolpos[1]);
		}),nullptr));
    

    for (int i = 1; i <= 8; i++) {
        if (i == 1) {
            useTool[i] = Sprite::create("useTool1_1.png");
        }else{
            useTool[i] = Sprite::create(__String::createWithFormat("useTool%d.png",i)->getCString());}
        useTool[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(useTool[i],1);
        useTool[i]->setPosition(Vec2(toolpos[i].x,SCALE_RATIO_Y*-1120));

    }
    useTool[3]->setAnchorPoint(Point(0.5,0.1));
    useTool[6]->setAnchorPoint(Point(0.5,0.1));
    useTool[7]->setAnchorPoint(Point(0.5,0.1));
    useTool[8]->setAnchorPoint(Point(0.5,0.1));
    
    useTool[2]->runAction(RepeatForever::create(Sequence::create(ScaleTo::create(0.4, 0.9),ScaleTo::create(0.4, 1.0), NULL)));
   
    showerpipe = Sprite::create("useTool3_1.png");
    showerpipe->setScale(1.0);
    useTool[3]->addChild(showerpipe);
    showerpipe->setPosition(Vec2(122,-357));

    for (int i = 1; i <= 4; i++) {
        popupUseTool[i] = Sprite::create(__String::createWithFormat("PopTool%d.png",i)->getCString());
        popupUseTool[i]->setScale(SCALE_RATIO_X,SCALE_RATIO_Y);
        this->addChild(popupUseTool[i],1);
        popupUseTool[i]->setPosition(Vec2(SCALE_RATIO_X*1200,SCALE_RATIO_Y*288));
        popupUseTool[i]->setAnchorPoint(Point(0.5,0.2));
        popupUseTool[i]->setRotation(-20);
        popupUseTool[i]->setOpacity(254);
    }
}
bool ManicureView::onTouchBegan(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
    if (isPopupFlag == true) {
        if(popupUseTool[1]->getBoundingBox().containsPoint(location) && popupUseTool[1]->getOpacity() == 255){
            popupUseTool[1]->setOpacity(254);
            if(MUSIC == true) ToolTapSound
            popupMoveFlag[1] = true;
            handHint->setVisible(false);
            handHint->stopAllActions();
        }
        
        if(popupUseTool[2]->getBoundingBox().containsPoint(location) && popupUseTool[2]->getOpacity() == 255){
            popupUseTool[2]->setOpacity(254);
            if(MUSIC == true) ToolTapSound
            popupMoveFlag[2] = true;
            handHint->setVisible(false);
            handHint->stopAllActions();

        }
        
        if(popupUseTool[3]->getBoundingBox().containsPoint(location) && popupUseTool[3]->getOpacity() == 255){
            popupUseTool[3]->setOpacity(254);
            if(MUSIC == true) ToolTapSound
            popupMoveFlag[3] = true;
            handHint->setVisible(false);
            handHint->stopAllActions();

        }
        
        if(popupUseTool[4]->getBoundingBox().containsPoint(location) && popupUseTool[4]->getOpacity() == 255){
            popupUseTool[4]->setOpacity(254);
            if(MUSIC == true) ToolTapSound
            popupMoveFlag[4] = true;
            handHint->setVisible(false);
            handHint->stopAllActions();
            particle_Steam->setVisible(true);

        }
    }
    else{
        if(btn_home->getBoundingBox().containsPoint(location) && btn_home->getOpacity() == 255){
            btn_home->runAction(Sequence::create(ScaleTo::create(0.2, 0.8),ScaleTo::create(0.2, 1.0), NULL));
            btn_home->setOpacity(254);
            if(MUSIC == true) UIButtonSound
            Director::getInstance()->replaceScene(TransitionFade::create(0.5f, Main_View::create()));
        }

        if (setting_button->getBoundingBox().containsPoint(touch->getLocation()) && isSettingTouch == false)
        {
            isSettingTouch = true;
            this->scheduleOnce(schedule_selector(ManicureView::istouchEnabled), 0.7);
            
            if (settingFlag == false)
            {
                // OPEN PANEL
                settingFlag = true;
                
                setting_button->runAction(RotateBy::create(0.5, 360));
                sound_button->runAction(Spawn::create(
                                                      MoveTo::create(0.5, Point(SCALE_RATIO_X*175, SCALE_RATIO_Y*960)),
                                                      RotateBy::create(0.5, 360),
                                                      NULL));
                home_button->runAction(Spawn::create(
                                                     MoveTo::create(0.5, Point(SCALE_RATIO_X*284, SCALE_RATIO_Y*960)),
                                                     RotateBy::create(0.5, 360),
                                                     NULL));
            }
            else
            {
                // CLOSE PANEL
                settingFlag = false;
                
                setting_button->runAction(RotateBy::create(0.5, -360));
                sound_button->runAction(Spawn::create(
                                                      MoveTo::create(0.5, Point(SCALE_RATIO_X*70, SCALE_RATIO_Y*960)),
                                                      RotateBy::create(0.5, 360),
                                                      NULL));
                home_button->runAction(Spawn::create(
                                                     MoveTo::create(0.5, Point(SCALE_RATIO_X*70, SCALE_RATIO_Y*960)),
                                                     RotateBy::create(0.5, 360),
                                                     NULL));
            }
            
            return true;
        }
        
        if (settingFlag == true)
        {
            if (home_button->getBoundingBox().containsPoint(touch->getLocation()))
            {
                if (MUSIC)
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Tap Button.mp3");
                
                Director::getInstance()->replaceScene(
                                                      TransitionFade::create(1.0, Main_View::createScene()));
            }
            else if (sound_button->getBoundingBox().containsPoint(touch->getLocation()))
            {
                if (MUSIC)
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Tap Button.mp3");
                
                if (MUSIC)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0);
                    sound_button->setTexture("level_mute_btn.png");
                    MUSIC = false;
                }
                else
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(1);
                    sound_button->setTexture("level_sound_btn.png");
                    MUSIC = true;
                }
            }
        }
    if(PanelTool[1]->getBoundingBox().containsPoint(location) && PanelTool[1]->getOpacity() == 255 && ToolNo == 0){
        if(MUSIC == true) ToolTapSound
        PanelTool[1]->setOpacity(0);
        useTool[1]->setPosition(location);
        moveToolFlag[1] = true;
        handHint->setVisible(false);
        handHint->stopAllActions();

    }
    if(PanelTool[2]->getBoundingBox().containsPoint(location) && PanelTool[2]->getOpacity() == 255 && ToolNo == 1){
        if(MUSIC == true) ToolTapSound
        PanelTool[2]->setOpacity(0);
        useTool[2]->setPosition(location);
        moveToolFlag[2] = true;
        handHint->stopAllActions();
        handHint->setVisible(false);

    }
    if(PanelTool[3]->getBoundingBox().containsPoint(location) && PanelTool[3]->getOpacity() == 255){
        if(MUSIC == true) ToolTapSound
        PanelTool[3]->setOpacity(0);
        useTool[3]->setPosition(location);
        moveToolFlag[3] = true;
        particle_Shower->setVisible(true);
        handHint->setVisible(false);
        handHint->stopAllActions();

    }
    if(PanelTool[4]->getBoundingBox().containsPoint(location) && PanelTool[4]->getOpacity() == 255){
        if(MUSIC == true) ToolTapSound
        PanelTool[4]->setOpacity(0);
        useTool[4]->setPosition(location);
        moveToolFlag[4] = true;
        handHint->setVisible(false);
        handHint->stopAllActions();

    }
    if(PanelTool[5]->getBoundingBox().containsPoint(location) && PanelTool[5]->getOpacity() == 255){
        PanelTool[5]->setOpacity(254);
        handHint->setVisible(false);
        handHint->stopAllActions();
        ToolTapSound
        if (MUSIC == true) {
            CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("popupopen.mp3");
        }
        vw_pop->runAction(Sequence::create(DelayTime::create(0.5),CallFunc::create([this]{black_M_bg->setVisible(true);}),ScaleTo::create(0.5, SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0), NULL));
        vw_hand->runAction(Sequence::create(DelayTime::create(0.5),ScaleTo::create(0.5, SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0), NULL));
        isPopupFlag = true;
        popupUseTool[1]->runAction(Sequence::create(DelayTime::create(1.5),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),MoveTo::create(1.0, Vec2(SCALE_RATIO_X*620,SCALE_RATIO_Y*112)),FadeIn::create(0.0),CallFunc::create([this](){
            pimpleHint(Vec2(SCALE_RATIO_X*605,SCALE_RATIO_Y*202));
            
            
        }), NULL));
    }
    }
    if(PanelTool[6]->getBoundingBox().containsPoint(location) && PanelTool[6]->getOpacity() == 255){
        PanelTool[6]->setOpacity(254);
        if(MUSIC == true) ToolTapSound
        PanelTool[6]->setTexture("PanelTool6_1.png");
        useTool[6]->setPosition(location);
        moveToolFlag[6] = true;
        useTool[6]->setPosition(location);
        handHint->setVisible(false);
        handHint->stopAllActions();

    }
    
    if(PanelTool[7]->getBoundingBox().containsPoint(location) && PanelTool[7]->getOpacity() == 255){
        PanelTool[7]->setOpacity(0);
        if(MUSIC == true) ToolTapSound
        useTool[7]->setPosition(location);
        moveToolFlag[7] = true;
        handHint->setVisible(false);
        handHint->stopAllActions();
        particleNo = 1;

    }
    if(PanelTool[8]->getBoundingBox().containsPoint(location) && PanelTool[8]->getOpacity() == 255){
        PanelTool[8]->setOpacity(0);
        if(MUSIC == true) ToolTapSound
        useTool[8]->setPosition(location);
        moveToolFlag[8] = true;
        handHint->setVisible(false);
        handHint->stopAllActions();
        particleNo = 2;

    }
  
    return true;
}
void ManicureView::onTouchMoved(Touch* touch, Event* event)
{
    Point location = this->convertToNodeSpace(touch->getLocation());
   //showerpipe->setPosition(location);
    
    if (moveToolFlag[1] == true) {
        useTool[1]->setPosition(location);
        moveDot->setPosition(Point(location.x-25,location.y+115));
        
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(pinksoapdummy[i]->getBoundingBox()) && soapDone[i] == false) {
                soapDone[i] = true;
                soapcnt++;
                moveToolFlag[1] = false;
                useTool[1]->setPosition(location);
                pinksoapdummy[i]->setPosition(outPosition);
                pinksoap[i]->runAction(Sequence::create(DelayTime::create(0.15),FadeIn::create(0.0), NULL));
                Animation* tempAnim = Animation::create();
                tempAnim->addSpriteFrameWithFile("useTool1_1.png");
                tempAnim->addSpriteFrameWithFile("useTool1.png");
                tempAnim->addSpriteFrameWithFile("useTool1_1.png");
                tempAnim->setDelayPerUnit(0.1f);
                
                Animate* animate = Animate::create(tempAnim);
                
                // Run full sequence
                if (MUSIC == true) {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("put.mp3");
                }
                useTool[1]->runAction(Sequence::create(animate,MoveTo::create(0.5f, PanelTool[1]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {
                    PanelTool[1]->setOpacity(255);
                    startSoapHint(toolpos[1]);
                }),nullptr));
            }
        }
        if (soapcnt >= 3) {
            soapcnt = 0;
            ToolNo = 1;
            scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.5);
            scheduleOnce(schedule_selector(ManicureView::toolComplete),3.0);
        }
        
    }
    if (moveToolFlag[2] == true) {
    
        useTool[2]->setPosition(location);
        moveDot->setPosition(Point(location.x,location.y));
        for (int i = 1; i <= 30; i++) {
            if (moveDot->getBoundingBox().intersectsRect(bubbledummy[i]->getBoundingBox()) && bubble[i]->getOpacity() == 0) {
                bubble[i]->setOpacity(255);
                bubble[i]->runAction(ScaleTo::create(0.2, SCALE_RATIO_X*1.0,SCALE_RATIO_Y*1.0));

                if (MUSIC == true) {
                    CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("bubble.mp3");
                }

                handFullDust->setOpacity(handFullDust->getOpacity() - 2);
                bubblecnt++;
                if (bubblecnt == 22) {
                    isbubble11 = true;
                }
            }
        }
        if (isbubble11 == true) {
            isbubble11 = false;
            for (int i = 1; i <= 3; i++) {
                handDust[i]->runAction(Sequence::create(FadeOut::create(2.0), NULL));
                handDotDust[i]->runAction(Sequence::create(FadeOut::create(2.0), NULL));
                pinksoap[i]->runAction(Sequence::create(FadeOut::create(2.0), NULL));
            }
        }
        if (bubblecnt == 30) {
            bubblecnt = 0;
            for (int i = 1; i <= 3; i++) {
                pinksoap[i]->setOpacity(0);
                handDust[i]->setOpacity(0);
                handDotDust[i]->setOpacity(0);
            }
            handFullDust->setOpacity(0);
            moveToolFlag[2] = false;
            useTool[2]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[2]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[2]->setOpacity(255);
                ToolNo = 2;
                scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.2);
                scheduleOnce(schedule_selector(ManicureView::toolComplete),3.0);
				}),nullptr));
        }
    }
    if (moveToolFlag[3] == true) {
        useTool[3]->setPosition(location);
        moveDot->setPosition(Point(location.x-20,location.y+100));
        if (MUSIC == true)
        {
            if(ShowerSoundFlag == 0)
            {
                ShowerSoundFlag = 1;
                ShowerSound = CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("water.mp3", true);
            }
            
        }
        particle_Shower->setPosition(Point(location.x-20, location.y+190));

        for (int i = 1; i <= 30; i++) {
            if (moveDot->getBoundingBox().intersectsRect(bubble[i]->getBoundingBox()) && bubble[i]->getOpacity() == 255) {
                bubble[i]->setOpacity(0);
                bubblecnt++;
                
            }
        }
        if (bubblecnt == 30) {
            bubblecnt = 0;
            moveToolFlag[3] = false;
            if(ShowerSoundFlag == 1)
            {
                ShowerSoundFlag = 0;
                CocosDenshion::SimpleAudioEngine::getInstance()->stopEffect(ShowerSound);
                
            }
            particle_Shower->setVisible(false);
            particle_Shower->setPosition(OUTOFSCREEN);
            useTool[3]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[3]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {
                PanelTool[3]->setOpacity(255);
                ToolNo = 3;
                scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.2);
                scheduleOnce(schedule_selector(ManicureView::toolComplete),3.0);
                }),nullptr));
        }
    }
    if (moveToolFlag[4] == true){
        useTool[4]->setPosition(location);
        moveDot->setPosition(Vec2(location.x+30, location.y+100));
        if (moveDot->getBoundingBox().intersectsRect(pimple[8]->getBoundingBox()))
        {
            if (MUSIC== true)
            {
                if(TowelSoundFlag==0)
                {
                    TowelSoundFlag=1;
                    TowelSound = CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("towel_rub.mp3", true);
                }
                
            }
            GLubyte opacity = pimple[8]->getOpacity();
            if (opacity > 0)
            {
                opacity = (opacity > 10) ? opacity - 10 : 0;
                pimple[8]->setOpacity(opacity);
            }
            if (opacity == 0) {
                moveToolFlag[4] = false;
                if(TowelSoundFlag==1)
                {
                    TowelSoundFlag=0;
                    CocosDenshion::SimpleAudioEngine::getInstance()->stopEffect(TowelSound);
                    
                }

                useTool[4]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[4]->getPosition()),MoveTo::create(0.0f, outPosition),
                    CallFunc::create([this]() {
                    PanelTool[4]->setOpacity(255);
                    ToolNo = 4;
                    scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),0.6);
                    scheduleOnce(schedule_selector(ManicureView::toolComplete),1.5);
                    }),nullptr));
            }
        }
        
    }
    if (moveToolFlag[6] == true) {
        useTool[6]->setPosition(location);
        moveDot->setPosition(Point(location.x+10,location.y+150));
        
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(whitecream[i]->getBoundingBox()) && whitecream[i]->getOpacity() == 0) {
                soapcnt++;
                soapDone[i] = true;
                whitecream[i]->setOpacity(255);
            }
        }
        if (soapcnt >= 3) {
            moveToolFlag[6] = false;
            soapcnt = 0;
            useTool[6]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[6]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[6]->setTexture("PanelTool6.png");
                }),nullptr));
            ToolNo = 6;
            scheduleOnce(schedule_selector(ManicureView::toolComplete),1.5);
        }
        
    }
    if (whitecreamFlag == true) {
        moveDot->setPosition(location.x,location.y);
        handHint->stopAllActions();
        handHint->setVisible(false);
        for (int i = 1; i <= 3; i++) {
                    if (moveDot->getBoundingBox().intersectsRect(
                            whitecream[i]->getBoundingBox())) {

                        whitecream[i]->setScale(whitecream[i]->getScale()+ 0.1);
                        GLubyte opacity = whitecream[i]->getOpacity();

                        if (opacity > 0) {
                            opacity = (opacity > 10) ? opacity - 10 : 0;
                            whitecream[i]->setOpacity(opacity);
                            if (opacity == 0 ) {
                        	pimplecount++;
                                
                    }
                }
            }
            if (pimplecount >= 3) {
                pimplecount = 0;
                ToolNo = 7;
                whitecreamFlag = false;
                scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.2);
                scheduleOnce(schedule_selector(ManicureView::toolComplete), 2.2);
            }
        }
    }
    
    if (moveToolFlag[7] == true) {
        useTool[7]->setPosition(location);
        moveDot->setPosition(location.x-5,location.y+205);

        static bool isTool7AnimRunning = false;

        Animation* tempAnim = Animation::create();
        tempAnim->addSpriteFrameWithFile("useTool7_1.png");
        tempAnim->addSpriteFrameWithFile("useTool7_2.png");
        tempAnim->addSpriteFrameWithFile("useTool7_3.png");
        tempAnim->setDelayPerUnit(0.1f);
        tempAnim->setLoops(-1);   // continuous animation

        Animate* animate = Animate::create(tempAnim);

        
        for (int i = 1; i <= 5; i++) {
                    if (moveDot->getBoundingBox().intersectsRect(
                            Dust_Nail[i]->getBoundingBox())) {
                            
                                if (!isTool7AnimRunning) {
                                            isTool7AnimRunning = true;
                                            useTool[7]->runAction(animate);
                                        }
                                GLubyte opacity = Dust_Nail[i]->getOpacity();

                        if (opacity > 0) {
                            opacity = (opacity > 10) ? opacity - 10 : 0;
                            Dust_Nail[i]->setOpacity(opacity);
                            if (opacity == 0 ) {
                                pimplecount++;
                                pimpleDone[i] = true;
                                ManicureView::handcleanParticle(Dust_Nail[i]->getPosition());
                    }
                }
            }
            if (pimplecount >= 5) {
                pimplecount = 0;
                ToolNo = 8;
                moveToolFlag[7] = false;
                isTool7AnimRunning = false;
                useTool[7]->stopAllActions();
                useTool[7]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[7]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[7]->setOpacity(254);
                    }),nullptr));
                scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.2);
                scheduleOnce(schedule_selector(ManicureView::toolComplete), 2.2);
            }
        }
        
    }
    
    if (moveToolFlag[8] == true) {
        useTool[8]->setPosition(location);
        moveDot->setPosition(location.x-5,location.y+215);
        
        for (int i = 1; i <= 5; i++) {
            if (moveDot->getBoundingBox().intersectsRect(Brok_Nail[i]->getBoundingBox()) && Brok_Nail[i]->getOpacity() == 255) {
                if (MUSIC == true) {
                    CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Twizzer.mp3");
                }
                Brok_Nail[i]->setOpacity(0);
                pimplecount++;
                pimpleDone[i] = true;
                ManicureView::handcleanParticle(Brok_Nail[i]->getPosition());

            }
            
        }
        if (pimplecount >= 5) {
            CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
            pimplecount = 0;
            ToolNo = 9;
            moveToolFlag[8] = false;
            useTool[8]->runAction(Sequence::create(MoveTo::create(0.5f, PanelTool[8]->getPosition()),MoveTo::create(0.0f, outPosition),CallFunc::create([this]() {PanelTool[8]->setOpacity(254);
            }),nullptr));
            scheduleOnce(schedule_selector(ManicureView::toolComplete), 1.2);
        }
    }
    if (popupMoveFlag[1] == true) {
        popupUseTool[1]->setPosition(location);
        moveDot->setPosition(location.x-115, location.y+330);
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(vw_pimpledummy[i]->getBoundingBox()) && vw_pimpledummy[i]->getOpacity() == 0) {
                pimpleDone[i] = true;
                if (MUSIC == true) {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Pimple Burst.mp3");
                }
                pimplecount++;
                vw_pimpledummy[i]->setOpacity(1);
                pimpleNo = i;
                vw_pimple[i]->setTexture("pimple4.png");
                pimpledust[i]->runAction(Sequence::create(DelayTime::create(0.2),FadeIn::create(0.0), NULL));
                pimpleclean[i]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0.0),CallFunc::create([this]{
                    pimpledust[pimpleNo]->setOpacity(0);
                    
                }), NULL));
            }
        }
        if (pimplecount >= 3) {
            pimplecount = 0;
            popupToolComplete = 1;
            popupMoveFlag[1] = false;
            popupUseTool[1]->setOpacity(254);
            popupUseTool[1]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),MoveTo::create(0.8,Vec2(SCALE_RATIO_X*1350,SCALE_RATIO_Y*288)),CallFunc::create([this]{for (int i = 1; i <= 3; i++) {
                vw_pimpledummy[i]->setOpacity(0);
            }}), NULL));
            scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.2);
            scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 2.1);
        }
    }
    if (popupMoveFlag[2] == true) {
        popupUseTool[2]->setPosition(location);
        moveDot->setPosition(location.x - 50,location.y + 170);
        for (int i = 1; i <= 3; i++) {
            if (moveDot->getBoundingBox().intersectsRect(
                    pimplecleandummy[i]->getBoundingBox())) {

                GLubyte opacity = pimpleclean[i]->getOpacity();

                if (opacity > 0) {
                    opacity = (opacity > 20) ? opacity - 20 : 0;
                    pimpleclean[i]->setOpacity(opacity);
                    if (opacity == 0 ) {
                        pimplecount++;
                        pimpleDone[i] = true;
                        ManicureView::handcleanParticle(pimplecleandummy[i]->getPosition());
                    }
                }
            }
            if (pimplecount >= 3) {
                pimplecount = 0;
                popupToolComplete = 2;
                popupMoveFlag[2] = false;
                popupUseTool[2]->setOpacity(254);
                popupUseTool[2]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*450,SCALE_RATIO_Y*288)),MoveTo::create(0.5,Vec2(SCALE_RATIO_X*1250,SCALE_RATIO_Y*288)), NULL));
                scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 1.2);
            }
        }
    }
    if (popupMoveFlag[3] == true) {
        popupUseTool[3]->setPosition(location);
        moveDot->setPosition(location.x-90,location.y+270);
        for (int i = 1; i <= 3; i++) {
            if(moveDot->getBoundingBox().intersectsRect(vw_pimpledummy[i]->getBoundingBox()) && vw_pimpledummy[i]->getOpacity() == 0) {
                vw_pimpledummy[i]->setOpacity(1);
                pimplecount++;
                pimpleDone[i] = true;
                vw_pimple[i]->runAction(Sequence::create(DelayTime::create(0.5),CallFunc::create([this,i]{vw_pimple[i]->setTexture("pimple1_3.png");                ManicureView::handcleanParticle(vw_pimpledummy[i]->getPosition());}), NULL));
            }
        }
        if (pimplecount >= 3) {
            for (int i = 1; i <= 3; i++) {
                vw_pimpledummy[i]->setOpacity(0);
            }
            pimplecount = 0;
            popupToolComplete = 3;
            popupMoveFlag[3] = false;
            popupUseTool[3]->setOpacity(254);
            popupUseTool[3]->runAction(Sequence::create(DelayTime::create(0.5),MoveTo::create(0.8,Vec2(SCALE_RATIO_X*590,SCALE_RATIO_Y*164)),MoveTo::create(0.5,Vec2(SCALE_RATIO_X*1350,SCALE_RATIO_Y*288)), NULL));
            scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 1.5);

        }
    }
    if (popupMoveFlag[4] == true) {
        popupUseTool[4]->setPosition(location);
        moveDot->setPosition(Vec2(location.x-125,location.y +270));
        particle_Steam->setPosition(Point(location.x-125, location.y+270));

            for (int i = 1; i <= 7; i++) {
                if (moveDot->getBoundingBox().intersectsRect(
                        vw_pimpledummy[i]->getBoundingBox())) {
                    if (MUSIC == true)
                    {
                        if(SteamSoundFlag == 0)
                        {
                            SteamSoundFlag = 1;
                            SteamSound = CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Steam.mp3", true);
                        }
                        
                    }

                    GLubyte opacity = vw_pimple[i]->getOpacity();

                    if (opacity > 0) {
                        opacity = (opacity > 30) ? opacity - 30 : 0;
                        vw_pimple[i]->setOpacity(opacity);

                        if (opacity == 0 ) {
                            pimplecount++;
                            pimpleDone[i] = true;
                            ManicureView::handcleanParticle(vw_pimpledummy[i]->getPosition());
                            
                        }
                    }
                }
        }
        if (pimplecount >= 7) {
            pimplecount = 0;
            popupToolComplete = 4;
            popupMoveFlag[4] = false;
            popupUseTool[4]->setOpacity(254);
            for (int i = 1; i <= 8; i++) {
                pimple[i]->setPosition(OUTOFSCREEN);
            }
            if(SteamSoundFlag == 1)
            {
                SteamSoundFlag = 0;
                CocosDenshion::SimpleAudioEngine::getInstance()->stopEffect(SteamSound);
                
            }
            particle_Steam->setVisible(false);
            particle_Steam->setPosition(OUTOFSCREEN);
            popupUseTool[4]->runAction(Sequence::create(MoveTo::create(0.8,Vec2(SCALE_RATIO_X*540,SCALE_RATIO_Y*110)),MoveTo::create(0.5,Vec2(SCALE_RATIO_X*1350,SCALE_RATIO_Y*288)), NULL));
            scheduleOnce(schedule_selector(ManicureView::ToolCompeleteParticle),1.7);
            scheduleOnce(schedule_selector(ManicureView::popuptoolComplete), 2.7);

        }
    }
    
}
void ManicureView::onTouchEnded(Touch* touch, Event* event)
{
    
    Point location = this->convertToNodeSpace(touch->getLocation());
    SimpleAudioEngine::getInstance()->end();
    

    log("shower_[%d]->setPosition(Vec2(%3.0f,%3.0f));",t,location.x,location.y);
  // log("vw_pimpledummy[%d]->setPosition(Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y));",t,location.x,location.y);
   // log("toolpos[%d] = Vec2(%3.0f*SCALE_RATIO_X,%3.0f*SCALE_RATIO_Y);",t,location.x,location.y);

    t++;

    
    if (moveToolFlag[1] == true)
    {
        moveToolFlag[1] = false;
        useTool[1]->runAction(
            Sequence::create(
                MoveTo::create(0.5, PanelTool[1]->getPosition()),
                MoveTo::create(0.0, outPosition),
                CallFunc::create([this]() {
                    PanelTool[1]->setOpacity(255);
                startSoapHint(toolpos[1]);
                }),
                nullptr
            )
        );
    }
    if (moveToolFlag[2] == true) {
        moveToolFlag[2] = false;
        useTool[2]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[2]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
        PanelTool[2]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0),CallFunc::create([this]() {
            showHint(toolpos[2],Vec2(SCALE_RATIO_X*384,SCALE_RATIO_Y*512));
        }), NULL));
    }
    if (moveToolFlag[3] == true) {
        moveToolFlag[3] = false;
        if(ShowerSoundFlag == 1)
        {
            ShowerSoundFlag = 0;
            CocosDenshion::SimpleAudioEngine::getInstance()->stopEffect(ShowerSound);
            
        }
        particle_Shower->setVisible(false);
        particle_Shower->setPosition(OUTOFSCREEN);
        useTool[3]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[3]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
        PanelTool[3]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0),CallFunc::create([this]() {
            showHint(toolpos[3],Vec2(SCALE_RATIO_X*384,SCALE_RATIO_Y*512));
        }), NULL));
    }
    
    if (moveToolFlag[4] == true){
        moveToolFlag[4] = false;
        if(TowelSoundFlag == 1)
        {
            TowelSoundFlag = 0;
            CocosDenshion::SimpleAudioEngine::getInstance()->stopEffect(TowelSound);
            
        }
    useTool[4]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[4]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
        PanelTool[4]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0),CallFunc::create([this]() {
            ManicureView::showHint(toolpos[4],Vec2(SCALE_RATIO_X*460,SCALE_RATIO_Y*535));

        }), NULL));
    }
    if (moveToolFlag[6] == true)
    {
        moveToolFlag[6] = false;
        useTool[6]->runAction(
            Sequence::create(
                MoveTo::create(0.5, PanelTool[6]->getPosition()),
                MoveTo::create(0.0, outPosition),
                CallFunc::create([this]() {
                    PanelTool[6]->setOpacity(255);
                    PanelTool[6]->setTexture("PanelTool6.png");
                startSoapHint(toolpos[6]);

                }),
                nullptr
            )
        );
    }
    if (moveToolFlag[7] == true)
    {
        moveToolFlag[7] = false;
        useTool[7]->stopAllActions();

        useTool[7]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[7]->getPosition()),MoveTo::create(0.0, outPosition), NULL));
        
        PanelTool[7]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0),CallFunc::create([this]() {
            pimpleHint(toolpos[7]);
        }), NULL));
    }
    if (moveToolFlag[8] == true)
    {
        moveToolFlag[8] = false;
        useTool[8]->runAction(Sequence::create(MoveTo::create(0.5,PanelTool[8]->getPosition()),MoveTo::create(0.0, outPosition), NULL));

        PanelTool[8]->runAction(Sequence::create(DelayTime::create(0.5),FadeIn::create(0),CallFunc::create([this]() {
            pimpleHint(toolpos[8]);
            
        }), NULL));
    }
    if (popupMoveFlag[1] == true){
        popupMoveFlag[1] = false;
        popupUseTool[1]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*620,SCALE_RATIO_Y*155)),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(Vec2(popupUseTool[1]->getPositionX(),popupUseTool[1]->getPositionY()));
        }), NULL));
    }
    
    if (popupMoveFlag[2] == true){
        popupMoveFlag[2] = false;
        popupUseTool[2]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*636,SCALE_RATIO_Y*121)),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(Vec2(popupUseTool[2]->getPositionX(),popupUseTool[2]->getPositionY()));
        }), NULL));
    }
    
    if (popupMoveFlag[3] == true){
        popupMoveFlag[3] = false;
        popupUseTool[3]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*590,SCALE_RATIO_Y*164)),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(Vec2(popupUseTool[3]->getPositionX(),popupUseTool[3]->getPositionY()));
        }), NULL));
    }
    if (popupMoveFlag[4] == true){
        popupMoveFlag[4] = false;
        particle_Steam->setVisible(false);
        if(SteamSoundFlag == 1)
        {
            SteamSoundFlag = 0;
            CocosDenshion::SimpleAudioEngine::getInstance()->stopEffect(SteamSound);
            
        }
        popupUseTool[4]->runAction(Sequence::create(MoveTo::create(0.5,Vec2(SCALE_RATIO_X*540,SCALE_RATIO_Y*110)),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(Vec2(popupUseTool[4]->getPositionX(),popupUseTool[4]->getPositionY()));
        }), NULL));
    }
}
void ManicureView::toolComplete(float d){
    
    if (ToolNo == 0) {
        PanelTool[1]->setOpacity(255);

    }
    else if (ToolNo == 1) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[2]->runAction(Sequence::create(DelayTime::create(1.2),FadeIn::create(0.0),CallFunc::create([this]() {
            ManicureView::showHint(toolpos[2],Vec2(384,512));
        }), NULL));
    }
    else if (ToolNo == 2) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[3]->runAction(Sequence::create(DelayTime::create(1.2),FadeIn::create(0.0),CallFunc::create([this]() {
            ManicureView::showHint(toolpos[3],Vec2(384,512));
        }), NULL));
    }
    else if (ToolNo == 3) {
     
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);

        PanelTool[1]->runAction(Sequence::create(DelayTime::create(1.2),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("exit_sfx.mp3");}),EaseSineIn::create(MoveTo::create(0.3, Vec2(toolpos[1].x,SCALE_RATIO_Y*-320))), NULL));
        PanelTool[2]->runAction(Sequence::create(DelayTime::create(1.2),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("exit_sfx.mp3");}),EaseSineIn::create(MoveTo::create(0.3, Vec2(toolpos[2].x,SCALE_RATIO_Y*-320))), NULL));
        PanelTool[3]->runAction(Sequence::create(DelayTime::create(1.2),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("exit_sfx.mp3");}),EaseSineIn::create(MoveTo::create(0.3, Vec2(toolpos[3].x,SCALE_RATIO_Y*-320))), NULL));

        PanelTool[4]->runAction(Sequence::create(DelayTime::create(1.5),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),MoveTo::create(0.5, toolpos[4]),DelayTime::create(1.2),FadeIn::create(0.0),CallFunc::create([this]() {
            ManicureView::showHint(toolpos[4],Vec2(SCALE_RATIO_X*460,SCALE_RATIO_Y*535));
        }), NULL));
        PanelTool[5]->runAction(Sequence::create(DelayTime::create(2.0),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),MoveTo::create(0.7, toolpos[5]), NULL));
        PanelTool[6]->runAction(Sequence::create(DelayTime::create(2.7),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),MoveTo::create(0.9, toolpos[6]), NULL));
    }
    if (ToolNo == 4) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[5]->runAction(Sequence::create(DelayTime::create(1.5),FadeIn::create(0.0),CallFunc::create([this]() {
            startTapHint(toolpos[5]);
        }), NULL));

    }
    if (ToolNo == 5) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[6]->runAction(Sequence::create(DelayTime::create(1.0),FadeIn::create(0.0),CallFunc::create([this]() {
            for (int i = 1; i <= 3; i++)
                soapDone[i] = false;
            currentSoapHint = -1;
            
            soapHintPos[1] = Vec2(253*SCALE_RATIO_X,356*SCALE_RATIO_Y);
            soapHintPos[2] = Vec2(395*SCALE_RATIO_X,463*SCALE_RATIO_Y);
            soapHintPos[3] = Vec2(456*SCALE_RATIO_X,277*SCALE_RATIO_Y);
            startSoapHint(toolpos[6]);
        }), NULL));

    }
    if (ToolNo == 6) {
        whitecreamFlag = true;
        Vec2 pos = Vec2(whitecream[1]->getPositionX(),whitecream[1]->getPositionY());
        ManicureView::startTapHint(pos);
    }
    if (ToolNo == 7) {
     
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);

        PanelTool[4]->runAction(Sequence::create(DelayTime::create(1.2),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("exit_sfx.mp3");}),MoveTo::create(0.3, Vec2(toolpos[4].x,SCALE_RATIO_Y*-220)), NULL));
        PanelTool[5]->runAction(Sequence::create(DelayTime::create(1.2),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("exit_sfx.mp3");}),MoveTo::create(0.3, Vec2(toolpos[5].x,SCALE_RATIO_Y*-220)), NULL));
        PanelTool[6]->runAction(Sequence::create(DelayTime::create(1.2),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("exit_sfx.mp3");}),MoveTo::create(0.3, Vec2(toolpos[6].x,SCALE_RATIO_Y*-220)), NULL));

        PanelTool[7]->runAction(Sequence::create(DelayTime::create(1.5),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),MoveTo::create(0.3, toolpos[7]),FadeIn::create(0.0),CallFunc::create([this]() {
            ManicureView::resethintvalue(4);
            pimpleHint(toolpos[7]);
        }), NULL));
        PanelTool[8]->runAction(Sequence::create(DelayTime::create(1.5),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),MoveTo::create(0.6, toolpos[8]), NULL));

    }
    if (ToolNo == 8) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        ManicureView::resethintvalue(4);
        PanelTool[8]->runAction(Sequence::create(DelayTime::create(1.2),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(toolpos[8]);
        }), NULL));

        
    }
    if (ToolNo == 9) {
        playCoinFly(Vec2(visibleSize.width / 2,visibleSize.height / 2),100);
        PanelTool[8]->runAction(Sequence::create(DelayTime::create(1.2),MoveTo::create(0.3, Vec2(toolpos[4].x,SCALE_RATIO_Y*-220)), NULL));
        PanelTool[7]->runAction(Sequence::create(DelayTime::create(1.2),MoveTo::create(0.3, Vec2(toolpos[5].x,SCALE_RATIO_Y*-220)),CallFunc::create([this]() {
           
            auto particle_levelcomp = ParticleSystemQuad::create("levelcomp.plist");
            particle_levelcomp->setLocalZOrder(100);
            this->addChild(particle_levelcomp);
            particle_levelcomp->setPosition(Vec2(SCALE_RATIO_X*384,SCALE_RATIO_Y*512));

            
            if (MUSIC == true) {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("Level Complete particle.mp3");
            }

            
        }), NULL));
        
        
        

    }
}
void ManicureView::popuptoolComplete(float d)
{
    if (popupToolComplete == 1) {
        ManicureView::resethintvalue(1);
        popupUseTool[2]->runAction(Sequence::create(MoveTo::create(1.0, Vec2(SCALE_RATIO_X*636,SCALE_RATIO_Y*155)),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(Vec2(popupUseTool[2]->getPositionX(),popupUseTool[2]->getPositionY()));
        }), NULL));

    }
    if (popupToolComplete == 2) {
        ManicureView::resethintvalue(0);
        popupUseTool[3]->runAction(Sequence::create(MoveTo::create(1.0, Vec2(SCALE_RATIO_X*594,SCALE_RATIO_Y*164)),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),FadeIn::create(0.0),CallFunc::create([this]() {
            pimpleHint(Vec2(popupUseTool[3]->getPositionX(),popupUseTool[3]->getPositionY()));
        }), NULL));
   }
    if (popupToolComplete == 3) {
        ManicureView::resethintvalue(3);
        popupUseTool[4]->runAction(Sequence::create(MoveTo::create(1.0, Vec2(SCALE_RATIO_X*540,SCALE_RATIO_Y*110)),CallFunc::create([](){
            if(MUSIC == true) CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("entry_sfx.mp3");}),FadeIn::create(0.0),CallFunc::create([this]() {
            isPopupLastTool = true;
            pimpleHint(Vec2(popupUseTool[4]->getPositionX(),popupUseTool[4]->getPositionY()));
        }), NULL));

    }
    if (popupToolComplete == 4) {
        vw_pop->runAction(Sequence::create(DelayTime::create(0.5),ScaleTo::create(0.5, SCALE_RATIO_X*0, SCALE_RATIO_Y*0),CallFunc::create([this]{black_M_bg->setVisible(false);}), NULL));
        if (MUSIC == true) {
            CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("popupclose.mp3");
        }
        vw_hand->runAction(Sequence::create(DelayTime::create(0.5),ScaleTo::create(0.5, SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0), NULL));
        isPopupFlag = false;
        ToolNo = 5;
        scheduleOnce(schedule_selector(ManicureView::toolComplete), 1.2);

    }

}
void ManicureView::openPopupView()
{
    vw_pop = Sprite::create("pimple_popup.png");
    vw_pop->setPosition(Vec2(386*SCALE_RATIO_X,523*SCALE_RATIO_Y));
    vw_pop->setScale(SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0);
    this->addChild(vw_pop);

    vw_hand = Sprite::create(__String::createWithFormat("p_hand_%d.png",handNo)->getCString());
    vw_hand->setPosition(Vec2(386*SCALE_RATIO_X,523*SCALE_RATIO_Y));
    vw_hand->setScale(SCALE_RATIO_X*0.0, SCALE_RATIO_Y*0.0);
    this->addChild(vw_hand);

    
    //set Pimple
    {
        for (int i = 1; i <= 7; i++) {
            vw_pimpledummy[i] = Sprite::create("pimple1_1.png");
            vw_pimpledummy[i]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
            this->addChild(vw_pimpledummy[i]);
            vw_pimpledummy[i]->setOpacity(0);
        }
        vw_pimpledummy[1]->setPosition(Vec2(500*SCALE_RATIO_X,551*SCALE_RATIO_Y));
        vw_pimpledummy[2]->setPosition(Vec2(251*SCALE_RATIO_X,452*SCALE_RATIO_Y));
        vw_pimpledummy[3]->setPosition(Vec2(164*SCALE_RATIO_X,669*SCALE_RATIO_Y));
        vw_pimpledummy[4]->setPosition(Vec2(256*SCALE_RATIO_X,694*SCALE_RATIO_Y));
        vw_pimpledummy[5]->setPosition(Vec2(272*SCALE_RATIO_X,321*SCALE_RATIO_Y));
        vw_pimpledummy[6]->setPosition(Vec2(550*SCALE_RATIO_X,434*SCALE_RATIO_Y));
        vw_pimpledummy[7]->setPosition(Vec2(495*SCALE_RATIO_X,805*SCALE_RATIO_Y));


        
        for (int i = 1; i <= 3; i++) {
            vw_pimple[i] = Sprite::create("pimple1_1.png");
            vw_hand->addChild(vw_pimple[i]);
            if (i == 1)
                vw_pimple[i]->setScale(1.0);
            else if (i == 2)
                vw_pimple[i]->setScale(0.7,0.7);
            else if (i == 3)
                vw_pimple[i]->setScale(0.4,0.4);
        }
        for (int i = 4; i <= 5; i++) {
            vw_pimple[i] = Sprite::create("pimple5.png");
            vw_hand->addChild(vw_pimple[i]);
            if (i == 4)
                vw_pimple[i]->setScale(0.9,0.9);
            else if (i == 5)
                vw_pimple[i]->setScale(0.6,0.6);
        }
        for (int i = 6; i <= 7; i++) {
            vw_pimple[i] = Sprite::create("pimple4.png");
            vw_hand->addChild(vw_pimple[i]);
            vw_pimple[i]->setScale(1.0);
        }
        vw_pimple[1]->setPosition(Vec2(456,389));
        vw_pimple[2]->setPosition(Vec2(205,290));
        vw_pimple[3]->setPosition(Vec2(118,507));
        vw_pimple[4]->setPosition(Vec2(211,531));
        vw_pimple[5]->setPosition(Vec2(227,159));
        vw_pimple[6]->setPosition(Vec2(506,273));
        vw_pimple[7]->setPosition(Vec2(449,642));

        for (int i = 1; i <= 3; i++) {
            pimpledust[i] = Sprite::create("pimple2.png");
            vw_hand->addChild(pimpledust[i]);
            pimpledust[i]->setScale(1);
            pimpledust[i]->setOpacity(0);
            
            pimpleclean[i] = Sprite::create("pimple3.png");
            vw_hand->addChild(pimpleclean[i]);
            pimpleclean[i]->setOpacity(0);

        }
        pimpledust[3]->setScale(0.4,0.4);
        pimpleclean[3]->setScale(0.5,0.5);

        pimpledust[2]->setFlippedX(true);
        pimpledust[3]->setFlippedX(true);

        pimpledust[1]->setPosition(Vec2(429,402));
        pimpledust[2]->setPosition(Vec2(230,307));
        pimpledust[3]->setPosition(Vec2(128,514));

        pimpleclean[1]->setPosition(Vec2(385,387));
        pimpleclean[2]->setPosition(Vec2(261,302));
        pimpleclean[3]->setPosition(Vec2(152,511));

        for (int i = 1; i <= 3; i++) {
            
            pimplecleandummy[i] = Sprite::create("pimple3.png");
            pimplecleandummy[i]->setScale(SCALE_RATIO_X*0.5,SCALE_RATIO_Y*0.5);
            this->addChild(pimplecleandummy[i]);
            pimplecleandummy[i]->setOpacity(0);

        }
        pimplecleandummy[1]->setPosition(Vec2(432*SCALE_RATIO_X,550*SCALE_RATIO_Y));
        pimplecleandummy[2]->setPosition(Vec2(306*SCALE_RATIO_X,465*SCALE_RATIO_Y));
        pimplecleandummy[3]->setPosition(Vec2(197*SCALE_RATIO_X,672*SCALE_RATIO_Y));

        
    }

}
void ManicureView::setCoinPanel(){
   
    coinpanel = Sprite::create("coin button.png");
    coinpanel->setPosition(Vec2(570*SCALE_RATIO_X,970*SCALE_RATIO_Y));
    coinpanel->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(coinpanel);

    coin_icon = Sprite::create("coin.png");
    coin_icon->setPosition(Vec2(530*SCALE_RATIO_X,970*SCALE_RATIO_Y));
    coin_icon->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
    this->addChild(coin_icon);

    CoinText = Label::createWithTTF(
        StringUtils::format("%d", CoinManager::getCoins()),
        "Marker Felt.ttf",
        20
    );
    CoinText->setAnchorPoint(Vec2(0, 0.5f));
    CoinText->setPosition(Vec2(80, coinpanel->getContentSize().height / 2));
    CoinText->setColor(Color3B(255, 20, 147)); 

    coinpanel->addChild(CoinText);
    
//    g_coins = UserDefault::getInstance()->getIntegerForKey("TOTAL_COINS", 1000);

}
void ManicureView::playCoinFly(Vec2 startPos, int coinCount)
{
    int flyCoins = 10;   // number of flying coins
    Vec2 endPos = coinpanel->getPosition();

    
    for (int i = 0; i < flyCoins; i++)
    {
        auto coin = Sprite::create("coin.png");
        coin->setPosition(startPos);
        coin->setScale(SCALE_RATIO_X*1.0, SCALE_RATIO_Y*1.0);
        this->addChild(coin, 20);

        float delay = i * 0.05f;

        // random curve offset
        Vec2 midPoint = startPos +
            Vec2(random(-100, 100), random(50, 150));

        auto bezier = BezierTo::create(
            0.6f,
            {
                startPos,
                midPoint,
                endPos
            }
        );

        auto action = Sequence::create(
            DelayTime::create(delay),
            Spawn::create(
                bezier,
                ScaleTo::create(0.6f, SCALE_RATIO_XY*0.3f),
                FadeOut::create(0.6f),
                nullptr
            ),
                                       
            RemoveSelf::create(),
            nullptr
        );

        coin->runAction(action);
        if (MUSIC == true) {
            CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("coin.mp3");
        }

    }

    Animation* tempAnim = Animation::create();
    tempAnim->addSpriteFrameWithFile("coinAnim1.png");
    tempAnim->addSpriteFrameWithFile("coinAnim2.png");
    tempAnim->addSpriteFrameWithFile("coinAnim3.png");
    tempAnim->addSpriteFrameWithFile("coinAnim4.png");
    tempAnim->addSpriteFrameWithFile("coinAnim3.png");
    tempAnim->addSpriteFrameWithFile("coinAnim2.png");
    tempAnim->addSpriteFrameWithFile("coinAnim1.png");
    tempAnim->addSpriteFrameWithFile("coin.png");
    tempAnim->setDelayPerUnit(0.1f);

    Animate* animate = Animate::create(tempAnim);

    coin_icon->runAction(animate);

    // update coins after animation
    this->runAction(
        Sequence::create(
            DelayTime::create(0.8f),
            CallFunc::create([=]() {
                CoinManager::addCoins(coinCount);
                CoinText->setString(
                    StringUtils::format("%d", CoinManager::getCoins())
                );

                // label bounce
                CoinText->runAction(
                    Sequence::create(
                        ScaleTo::create(0.1f, 1.2f),
                        ScaleTo::create(0.1f, 1.0f),
                        nullptr
                    )
                );
            }),
            nullptr
        )
    );
}
void ManicureView::startSoapHint(cocos2d::Vec2 start)
{
    if (!handHint)
        return;
    
    handHint->stopAllActions();
    
    
    int targetIndex = -1;
    for (int i = 1; i <= 3; i++){
        if (!soapDone[i]){
            targetIndex = i;
            break;
        }
    }
    if (targetIndex == -1)
    {
        handHint->setVisible(false);
        return;
    }
    handHint->setVisible(true);

    Vec2 startPos = start;
    Vec2 endPos = soapHintPos[targetIndex];
    
    handHint->setPosition(startPos);
    
    auto moveToSoap = MoveTo::create(1.0f, endPos);
    
    auto tapDown = MoveBy::create(0.25f, Vec2(0, -15));
    auto tapUp   = MoveBy::create(0.25f, Vec2(0, 15));
    
    //auto tapTwice = Sequence::create(tapDown, tapUp,tapDown, tapUp,nullptr);
    auto resetPos = CallFunc::create([=]() {handHint->setPosition(startPos);});
    
    auto fullHintLoop = RepeatForever::create(Sequence::create(moveToSoap,DelayTime::create(0.5f),resetPos,DelayTime::create(0.2f),nullptr));
        handHint->runAction(fullHintLoop);
}
void ManicureView::showHint(Vec2 start,Vec2 end)
{
    Vec2 startPos = start;
    Vec2 endPos = end;
    handHint->setVisible(true);
    handHint->setPosition(startPos);
    auto moveToTool = MoveTo::create(1.0f, endPos);
	auto resetPos = CallFunc::create([=]() {handHint->setPosition(startPos);});
    auto fullHintLoop = RepeatForever::create(Sequence::create(moveToTool,DelayTime::create(0.5f),resetPos,DelayTime::create(0.2f),nullptr));
	handHint->runAction(fullHintLoop);
}
void ManicureView::startTapHint(const cocos2d::Vec2& pos)
{
    if (!handHint)
        return;
    
    handHint->stopAllActions();
    handHint->setVisible(true);
    handHint->setPosition(pos);
    
    // Tap animation
    auto tapDown = MoveBy::create(0.4f, Vec2(0, -15));
    auto tapUp   = MoveBy::create(0.4f, Vec2(0,  15));
    
    auto tapOnce = Sequence::create(tapDown, tapUp, nullptr);
    
    auto tapLoop = RepeatForever::create(Sequence::create(tapOnce,DelayTime::create(0.6f),nullptr));
    
    handHint->runAction(tapLoop);
}

void ManicureView::stopTapHint()
{
    if (!handHint)
        return;
    
    handHint->stopAllActions();
    handHint->setVisible(false);
}
void ManicureView::pimpleHint(cocos2d::Vec2 start)
{
    
        
    
    if (!handHint)
        return;
    
    handHint->stopAllActions();
    
    
    int targetIndex = -1;
    
    if (isNailHint == true) {
        for (int i = 1; i <= 5; i++){
            if (!pimpleDone[i]){
                targetIndex = i;
                break;
            }
        }
    }
    if (isPopupLastTool == false) {
    for (int i = 1; i <= 3; i++){
        if (!pimpleDone[i]){
            targetIndex = i;
            break;
        }
    }
    }
    else{
        for (int i = 1; i <= 7; i++){
            if (!pimpleDone[i]){
                targetIndex = i;
                break;
            }
        }

    }
    if (targetIndex == -1)
    {
        handHint->setVisible(false);
        return;
    }
    handHint->setVisible(true);
    
    Vec2 startPos = start;
    Vec2 endPos = pimpleHintPos[targetIndex];
    
    handHint->setPosition(startPos);
    
    auto moveToPimple = MoveTo::create(1.0f, endPos);
    
    auto tapDown = MoveBy::create(0.25f, Vec2(0, -15));
    auto tapUp   = MoveBy::create(0.25f, Vec2(0, 15));
    
    //auto tapTwice = Sequence::create(tapDown, tapUp,tapDown, tapUp,nullptr);
    auto resetPos = CallFunc::create([=]() {handHint->setPosition(startPos);});
    
    auto fullHintLoop = RepeatForever::create(Sequence::create(moveToPimple,DelayTime::create(0.5f),resetPos,DelayTime::create(0.2f),nullptr));
    handHint->runAction(fullHintLoop);
}
void ManicureView::resethintvalue(int TNo){
    
    for (int i = 1; i <= 3; i++)
        pimpleDone[i] = false;
    currentPimpleHint = -1;

    if (TNo == 0 || TNo == 2) {
        pimpleHintPos[1] = Vec2(Vec2(510*SCALE_RATIO_X,531*SCALE_RATIO_Y));
        pimpleHintPos[2] = Vec2(Vec2(261*SCALE_RATIO_X,432*SCALE_RATIO_Y));
        pimpleHintPos[3] = Vec2(Vec2(174*SCALE_RATIO_X,649*SCALE_RATIO_Y));

    }

    else if (TNo == 1) {
        
        pimpleHintPos[1] = Vec2(Vec2(442*SCALE_RATIO_X,530*SCALE_RATIO_Y));
        pimpleHintPos[2] = Vec2(Vec2(316*SCALE_RATIO_X,445*SCALE_RATIO_Y));
        pimpleHintPos[3] = Vec2(Vec2(207*SCALE_RATIO_X,652*SCALE_RATIO_Y));
        
    }
    
    else if (TNo == 3) {
        
        for (int i = 1; i <= 7; i++)
            pimpleDone[i] = false;
        currentPimpleHint = -1;

        pimpleHintPos[1] = Vec2(530*SCALE_RATIO_X,541*SCALE_RATIO_Y);
        pimpleHintPos[2] = Vec2(281*SCALE_RATIO_X,442*SCALE_RATIO_Y);
        pimpleHintPos[3] = Vec2(194*SCALE_RATIO_X,659*SCALE_RATIO_Y);
        pimpleHintPos[4] = Vec2(256*SCALE_RATIO_X,684*SCALE_RATIO_Y);
        pimpleHintPos[5] = Vec2(302*SCALE_RATIO_X,311*SCALE_RATIO_Y);
        pimpleHintPos[6] = Vec2(580*SCALE_RATIO_X,424*SCALE_RATIO_Y);
        pimpleHintPos[7] = Vec2(525*SCALE_RATIO_X,795*SCALE_RATIO_Y);

        
    }

    else if (TNo == 4) {
        
        for (int i = 1; i <= 5; i++)
            pimpleDone[i] = false;
        currentPimpleHint = -1;
        
        pimpleHintPos[1] = Vec2(660*SCALE_RATIO_X,535*SCALE_RATIO_Y);
        pimpleHintPos[2] = Vec2(498*SCALE_RATIO_X,822*SCALE_RATIO_Y);
        pimpleHintPos[3] = Vec2(368*SCALE_RATIO_X,868*SCALE_RATIO_Y);
        pimpleHintPos[4] = Vec2(256*SCALE_RATIO_X,819*SCALE_RATIO_Y);
        pimpleHintPos[5] = Vec2(145*SCALE_RATIO_X,700*SCALE_RATIO_Y);
        
    }

}

void ManicureView::ToolCompeleteParticle(float d){
   
    auto toolparticle = ParticleSystemQuad::create("Tool_Complitfull.plist");
    toolparticle->setLocalZOrder(100);
    toolparticle->setPosition(Vec2(369*SCALE_RATIO_X,411*SCALE_RATIO_Y));
    this->addChild(toolparticle);

    
    if (MUSIC == true) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("done.mp3");
    }
    
}
void ManicureView::handcleanParticle(Vec2 pos){
    
    if (particleNo == 0) {
        auto toolparticle = ParticleSystemQuad::create("Tool_Complit.plist");
        toolparticle->setLocalZOrder(100);
        toolparticle->setPosition(pos);
        this->addChild(toolparticle,10);

    }
    else if (particleNo == 1){
        auto toolparticle = ParticleSystemQuad::create("nail_star.plist");
        toolparticle->setLocalZOrder(100);
        toolparticle->setPosition(pos);
        this->addChild(toolparticle,10);

    }
    else if (particleNo == 2){
        auto toolparticle = ParticleSystemQuad::create("nailParticle.plist");
        toolparticle->setLocalZOrder(100);
        toolparticle->setPosition(pos);
        this->addChild(toolparticle,10);
        
    }

    
    if (MUSIC == true) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("particle 1.mp3");
    }
    
}

void ManicureView::istouchEnabled(float d)
{
    isSettingTouch = false;
}
void ManicureView::istouchSetting(float d)
{
//    if (settingFlag == false)
//        settingFlag = true;
//    else
//        settingFlag = false;
}
